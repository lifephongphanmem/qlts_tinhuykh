<?php require ("$_SERVER[DOCUMENT_ROOT]/thoaikx/general.php"); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
<head>
	<title>Document</title>
	<meta HTTP-EQUIV='Content-Type' CONTENT='text/html; charset=UTF-8'>
	<style type="text/css">
		.cs61FA619A {color:#000000;background-color:transparent;border-left:#000000 1px solid;border-top:#000000 1px solid;border-right:#000000 1px solid;border-bottom-style: none;font-family:Times New Roman; font-size:13px; font-weight:bold; font-style:normal; }
		.csA96B98F9 {color:#000000;background-color:transparent;border-left:#000000 1px solid;border-top-style: none;border-right:#000000 1px solid;border-bottom:#000000 1px solid;font-family:Times New Roman; font-size:13px; font-weight:bold; font-style:normal; }
		.cs5017E93B {color:#000000;background-color:transparent;border-left:#000000 1px solid;border-top:#000000 1px solid;border-right:#000000 1px solid;border-bottom:#000000 1px solid;font-family:Times New Roman; font-size:13px; font-weight:normal; font-style:normal; }
		.cs5017E93Ba {color:#000000;background-color:transparent;border-left:#000000 1px solid;border-top-style: none;border-right:#000000 1px solid;border-bottom:#000000 1px solid;font-family:Times New Roman; font-size:13px; font-weight:normal; font-style:normal; }
		.csFFAD02AE {color:#000000;background-color:transparent;border-left:#000000 1px solid;border-top-style: none;border-right:#000000 1px solid;border-bottom-style: none;font-family:Times New Roman; font-size:13px; font-weight:bold; font-style:normal; }
		.csAB3AA82A {color:#000000;background-color:transparent;border-left-style: none;border-top:#000000 1px solid;border-right:#000000 1px solid;border-bottom:#000000 1px solid;font-family:Times New Roman; font-size:13px; font-weight:bold; font-style:normal; }
		.cs8FC8786E {color:#000000;background-color:transparent;border-left-style: none;border-top:#000000 1px solid;border-right:#000000 1px solid;border-bottom:#000000 1px solid;font-family:Times New Roman; font-size:13px; font-weight:bold; font-style:normal; }
		.cs8FC8786Ea {color:#000000;background-color:transparent;border-left-style: none;border-top-style: none;border-right:#000000 1px solid;border-bottom-style: none;font-family:Times New Roman; font-size:13px; font-weight:bold; font-style:normal; }
		.csA4A4F90C {color:#000000;background-color:transparent;border-left-style: none;border-top:#000000 1px solid;border-right:#000000 1px solid;border-bottom:#000000 1px solid;font-family:Times New Roman; font-size:13px; font-weight:normal; font-style:normal; }
		.csA4A4F90Ca {color:#000000;background-color:transparent;border-left-style: none;border-top-style: none;border-right:#000000 1px solid;border-bottom:#000000 1px solid;font-family:Times New Roman; font-size:13px; font-weight:normal; font-style:normal; }
		.csD3053F26 {color:#000000;background-color:transparent;border-left-style: none;border-top-style: none;border-right:#000000 1px solid;border-bottom-style: none;font-family:Times New Roman; font-size:13px; font-weight:bold; font-style:normal; }
		.csD3053F26a {color:#000000;background-color:transparent;border-left-style: none;border-top: #000000 1px solid;border-right:#000000 1px solid;border-bottom-style: none;font-family:Times New Roman; font-size:13px; font-weight:bold; font-style:normal; }
		.cs550435DA {color:#000000;background-color:transparent;border-left-style: none;border-top-style: none;border-right-style: none;border-bottom-style: none;font-family:Times New Roman; font-size:13px; font-weight:bold; font-style:normal; }
		.cs101A94F7 {color:#000000;background-color:transparent;border-left-style: none;border-top-style: none;border-right-style: none;border-bottom-style: none;font-family:Times New Roman; font-size:13px; font-weight:normal; font-style:normal; }
		.cs3D3BE940 {color:#000000;background-color:transparent;border-left-style: none;border-top-style: none;border-right-style: none;border-bottom-style: none;font-family:Times New Roman; font-size:15px; font-weight:bold; font-style:normal; }
		.cs54291A7F {color:#000000;background-color:transparent;border-left-style: none;border-top-style: none;border-right-style: none;border-bottom-style: none;font-family:Times New Roman; font-size:15px; font-weight:normal; font-style:italic; }
		.cs6B03CC12 {color:#000000;background-color:transparent;border-left-style: none;border-top-style: none;border-right-style: none;border-bottom-style: none;font-family:Times New Roman; font-size:15px; font-weight:normal; font-style:normal; }
		.csB6E29E9B {color:#000000;background-color:transparent;border-left-style: none;border-top-style: none;border-right-style: none;border-bottom-style: none;font-family:Times New Roman; font-size:16px; font-weight:bold; font-style:normal; }
		.csE9F2AA97 {color:#000000;background-color:transparent;border-left-style: none;border-top-style: none;border-right-style: none;border-bottom-style: none;font-family:Times New Roman; font-size:16px; font-weight:bold; font-style:normal; padding-left:2px;padding-right:2px;}
		.csCDE32A0F {color:#000000;background-color:transparent;border-left-style: none;border-top-style: none;border-right-style: none;border-bottom-style: none;font-family:Times New Roman; font-size:16px; font-weight:normal; font-style:italic; padding-left:2px;padding-right:2px;}
		.csF7D3565D {height:0px;width:0px;overflow:hidden;font-size:0px;line-height:0px;}
		@media print {
		   .in{
			  display: none !important;
		   }
		}
	</style>
<link rel="stylesheet" href="buttonPro.css"/>
</head>
<div class="in" style="margin-left: 1100px;">
<input  type="submit" class="buttonPro medium blue" onclick=" window.print()" value="In báo cáo"  />
<input type="button" class="buttonPro medium red" value="Thoát" onclick="window.location.href='<?php echo $_SERVER['HTTP_REFERER'];?>'" />	
</div>
<body leftMargin=10 topMargin=10 rightMargin=10 bottomMargin=10 style="background-color:#FFFFFF">
<?php	
	$denngay="";
	$tungay ="";
	$nam="";
	$noisd="";
	$loaicc="";
	$madv ="";
	$nam = "";
	if(isset($_POST['create']))
	{		
		//$denngay = $_POST['ntden'];
		//$tungay = $_POST['nttu'];
		$nam = $_POST['nam'];
		$noisd = $_POST['noisudung'];	
		$loaicc = $_POST['loaicc'];	
		$madv = explode('>',$_POST['MADV']);	
		$msdv = $madv[0];			
		if($_POST['donvi'] != "")
			$msdv = $_POST['donvi'];
	}
	?>
<table cellpadding="0" cellspacing="0" border="0" style="border-width:0px;empty-cells:show;">
	<tr>
		<td style="width:0px;height:0px;"></td>
		<td style="height:0px;width:77px;"></td>
		<td style="height:0px;width:53px;"></td>
		<td style="height:0px;width:76px;"></td>
		<td style="height:0px;width:144px;"></td>
		<td style="height:0px;width:53px;"></td>
		<td style="height:0px;width:58px;"></td>
		<td style="height:0px;width:77px;"></td>
		<td style="height:0px;width:96px;"></td>
		<td style="height:0px;width:52px;"></td>
		<td style="height:0px;width:77px;"></td>
		<td style="height:0px;width:108px;"></td>
		<td style="height:0px;width:57px;"></td>
		<td style="height:0px;width:77px;"></td>
		<td style="height:0px;width:96px;"></td>
	</tr>
	<tr style="vertical-align:top;">
		<td style="width:0px;height:19px;"></td>
		<td class="csB6E29E9B" rowspan="2" style="width:77px;height:20px;line-height:18px;text-align:left;vertical-align:middle;"><nobr>Bộ:</nobr></td>
		<td class="csB6E29E9B" colspan="6" rowspan="2" style="width:461px;height:20px;line-height:18px;text-align:left;vertical-align:middle;"><nobr></nobr></td>
		<td></td>
		<td></td>
		<td class="cs550435DA" colspan="5" style="width:415px;height:19px;line-height:15px;text-align:center;vertical-align:middle;"><nobr>Mẫu số : S26-H</nobr></td>
	</tr>
	<tr style="vertical-align:top;">
		<td style="width:0px;height:1px;"></td>
		<td></td>
		<td></td>
		<td class="cs101A94F7" colspan="5" rowspan="3" style="width:415px;height:40px;line-height:15px;text-align:center;vertical-align:middle;"><nobr>(Ban hành theo Thông tư số 107/2017/TT-BTC </br> ngày 10/10/2017 của Bộ Tài chính)</nobr></td>
	</tr>
	<tr style="vertical-align:top;">
		<td style="width:0px;height:20px;"></td>
		<td class="csB6E29E9B" style="width:77px;height:20px;line-height:18px;text-align:left;vertical-align:middle;"><nobr>Đơn&nbsp;vị:</nobr></td>
		<td class="csB6E29E9B" colspan="6" style="width:461px;height:20px;line-height:18px;text-align:left;vertical-align:middle; "><nobr><?php echo $madv[2]; ?></nobr></td>
		<td></td>
		<td></td>
	</tr>
	<tr style="vertical-align:top;">
		<td style="width:0px;height:19px;"></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
	</tr>
	<tr style="vertical-align:top;">
		<td style="width:0px;height:17px;"></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
	</tr>
	<tr style="vertical-align:top;">
		<td style="width:0px;height:22px;"></td>
		<td class="csE9F2AA97" colspan="14" style="width:1097px;height:22px;line-height:18px;text-align:center;vertical-align:middle;"><nobr>SỔ&nbsp;THEO&nbsp;D&#213;I&nbsp;DỤNG&nbsp;CỤ&nbsp;L&#194;U&nbsp;BỀN&nbsp;TẠI&nbsp;NƠI&nbsp;SỬ&nbsp;DỤNG</nobr></td>
	</tr>
	<tr style="vertical-align:top;">
	<?php			
	function my_sort($ar, $br)
		{ 					
			if ($ar["0"] == $br["0"]) 			 
				return 0;	
			return ($ar["0"] > $br["0"])? 1:-1;
		} 
		require("$_SERVER[DOCUMENT_ROOT]/Main/connect.php");		
		$ar = array(array("A","B","C","D",0,0,0,0,"E","F","G",0,0,0,0,0));
		$c=0;
		$Tsl1 = 0; $Tsl2 = 0; $Tsl3 = 0; $Tsl4 = 0;
		$sql = "Select ngayxuat,ttxuatdung,tenchitiet,dvt,soluong,dongia,sotien from tblxuatdung where madonvi Like '$msdv%'".
				" and mataisan like 'C%' ".
				($loaicc == ""?"":" and chitiethinhthai = '" . $loaicc . "'").($noisd == ""?"":" and noisudung = '" . $noisd . "'").
				($nam == ""?"": " and year(ngayxuat) = ".$nam);
				//($tungay == ""?"":" and ngayxuat >= '" . doingay($tungay) . "'").($denngay == ""?"":" and ngayxuat <= '" . doingay($denngay) . "'");
		$qrsql = mysqli_query($con,$sql);
		while ($row = mysqli_fetch_array($qrsql))		
		{
			$ar[$c][0] = $row['ngayxuat'];
			$ar[$c][1] = $row['ttxuatdung'];
			$ar[$c][2] = $row['tenchitiet'];
			$ar[$c][3] = $row['dvt'];
			$ar[$c][4] = $row['ngayxuat'];
			$ar[$c][5] = $row['soluong'];
			$ar[$c][6] = $row['dongia'];
			$ar[$c][7] = $row['sotien'];			
			$ar[$c][8] = "";
			$ar[$c][9] = "";
			$ar[$c][10] = "";
			$ar[$c][11] = 0;
			$ar[$c][12] = 0;
			$ar[$c][13] = 0;			
			$c++;			
		}
		$sql = "Select ngaythang,tenchitiet,TTbaohong,Lydohong,soluong,dongia,sotien,dvt from tblbaohong where madonvi Like '$msdv%'".
				"  and mataisan like 'C%' ".
				($loaicc == ""?"":" and chitiethinhthai = '" . $loaicc . "'").($noisd == ""?"":" and noibaohong = '" . $noisd . "'").
				($nam == ""?"": " and year(ngaythang) = ".$nam);
				//($tungay == ""?"":" and ngaythang >= '" . doingay($tungay) . "'").($denngay == ""?"":" and ngaythang <= '" . doingay($denngay) . "'");
		$qrsql = mysqli_query($con,$sql);
		while ($row = mysqli_fetch_array($qrsql))		
		{
			$ar[$c][0] = $row['ngaythang'];
			$ar[$c][1] = "";
			$ar[$c][2] = $row['tenchitiet'];
			$ar[$c][3] = $row['dvt'];
			$ar[$c][4] = "";
			$ar[$c][5] = 0;
			$ar[$c][6] = 0;
			$ar[$c][7] = 0;			
			$ar[$c][8] = $row['TTbaohong'];
			$ar[$c][9] = $row['ngaythang'];
			$ar[$c][10] = $row['Lydohong'];
			$ar[$c][11] = $row['soluong'];
			$ar[$c][12] = $row['dongia'];
			$ar[$c][13] = $row['sotien'];
			$c++;			
		}	
		uasort($ar,"my_sort");
	?>
		<td style="width:0px;height:22px;"></td>
		<td class="csE9F2AA97" colspan="14" style="width:1097px;height:22px;line-height:18px;text-align:center;vertical-align:middle;"><nobr>Năm: <?php echo $nam;?></nobr></td>
	</tr>
	<tr style="vertical-align:top;">
		<td  colspan="15" style="width:1097px;height:22px;line-height:18px;text-align:left;vertical-align:middle;"><nobr>Tên đơn vị, phòng ban (hoặc người sử dụng):&nbsp;<?php echo $noisd?></nobr></td>
	</tr>
	<tr style="vertical-align:top;">
		<td  colspan="15" style="width:1097px;height:22px;line-height:18px;text-align:left;vertical-align:middle;"><nobr>Loại công cụ, dụng cụ (hoặc nhóm công cụ, dụng cụ):&nbsp;<?php echo $loaicc?></nobr></td>
	</tr>
	<tr style="vertical-align:top;">
		<td style="width:0px;height:16px;"></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
	</tr>
	</table>
	<table cellpadding="0" cellspacing="0" border="0" style="border-width:0px;empty-cells:show;">
	<tr style="vertical-align:top;">
		<td style="width:0px;height:20px;"></td>
		<td class="cs61FA619A" rowspan="2" style="width:75px;height:20px;line-height:15px;text-align:center;vertical-align:middle;"><nobr>Ng&#224;y,&nbsp;th&#225;ng</nobr><br/><nobr>ghi&nbsp;sổ</nobr></td>
		<td class="cs8FC8786E" colspan="2" style="width:128px;height:20px;line-height:15px;text-align:center;vertical-align:middle;"><nobr>Chứng&nbsp;từ</nobr></td>
		<td class="csD3053F26a" rowspan="2" style="width:143px;height:20px;line-height:15px;text-align:center;vertical-align:middle;"><nobr>T&#234;n&nbsp;dụng&nbsp;cụ&nbsp;l&#226;u&nbsp;bền</nobr></td>
		<td class="csD3053F26a" rowspan="2" style="width:52px;height:20px;line-height:15px;text-align:center;vertical-align:middle;"><nobr>Đơn&nbsp;vị</nobr><br/><nobr>t&#237;nh</nobr></td>
		<td class="csAB3AA82A" colspan="3" style="width:556px;height:20px;line-height:15px;text-align:center;vertical-align:middle;"><nobr>Ghi&nbsp;tăng&nbsp;dụng&nbsp;cụ&nbsp;l&#226;u&nbsp;bền</nobr></td>
		<td class="csAB3AA82A" colspan="4" style="width:466px;height:20px;line-height:15px;text-align:center;vertical-align:middle;"><nobr>Ghi&nbsp;giảm&nbsp;dụng&nbsp;cụ&nbsp;l&#226;u&nbsp;bền</nobr></td>
	</tr>
	<tr style="vertical-align:middle;">
		<td style="width:0px;height:20px;"></td>
		<td class="cs8FC8786Ea" style="width:52px;height:18px;line-height:15px;text-align:center;vertical-align:middle;"><nobr>Số&nbsp;hiệu</nobr></td>
		<td class="cs8FC8786Ea" style="width:75px;height:18px;line-height:15px;text-align:center;vertical-align:middle;"><nobr>Ng&#224;y&nbsp;th&#225;ng</nobr></td>
		<td class="csD3053F26"  style="width:57px;height:20px;line-height:15px;text-align:center;vertical-align:middle;"><nobr>Số&nbsp;lượng</nobr></td>
		<td class="csD3053F26"  style="width:76px;height:20px;line-height:15px;text-align:center;vertical-align:middle;"><nobr>Đơn&nbsp;gi&#225;</nobr></td>
		<td class="csD3053F26"  style="width:95px;height:20px;line-height:15px;text-align:center;vertical-align:middle;"><nobr>&nbsp;Th&#224;nh&nbsp;tiền</nobr></td>
		<td class="csD3053F26"  style="width:107px;height:20px;line-height:15px;text-align:center;vertical-align:middle;"><nobr>L&#253;&nbsp;do</nobr></td>
		<td class="csD3053F26"  style="width:56px;height:20px;line-height:15px;text-align:center;vertical-align:middle;"><nobr>Số&nbsp;lượng</nobr></td>
		<td class="csD3053F26"  style="width:76px;height:20px;line-height:15px;text-align:center;vertical-align:middle;"><nobr>Đơn&nbsp;gi&#225;</nobr></td>
		<td class="csD3053F26"  style="width:95px;height:20px;line-height:15px;text-align:center;vertical-align:middle;"><nobr>Th&#224;nh&nbsp;&nbsp;tiền</nobr></td>
	</tr>
	<tr style="vertical-align:top;">
		<td style="width:0px;height:20px;"></td>
		<td class="cs5017E93B" style="width:75px;height:19px;line-height:15px;text-align:center;vertical-align:middle;"><nobr>A</nobr></td>
		<td class="csA4A4F90C" style="width:52px;height:19px;line-height:15px;text-align:center;vertical-align:middle;"><nobr>B</nobr></td>
		<td class="csA4A4F90C" style="width:75px;height:19px;line-height:15px;text-align:center;vertical-align:middle;"><nobr>C</nobr></td>
		<td class="csA4A4F90C" style="width:143px;height:19px;line-height:15px;text-align:center;vertical-align:middle;"><nobr>D</nobr></td>
		<td class="csA4A4F90C" style="width:52px;height:19px;line-height:15px;text-align:center;vertical-align:middle;"><nobr>1</nobr></td>
		<td class="csA4A4F90C" style="width:57px;height:19px;line-height:15px;text-align:center;vertical-align:middle;"><nobr>2</nobr></td>
		<td class="csA4A4F90C" style="width:76px;height:19px;line-height:15px;text-align:center;vertical-align:middle;"><nobr>3</nobr></td>
		<td class="csA4A4F90C" style="width:95px;height:19px;line-height:15px;text-align:center;vertical-align:middle;"><nobr>4</nobr></td>
		<td class="csA4A4F90C" style="width:51px;height:19px;line-height:15px;text-align:center;vertical-align:middle;"><nobr>E</nobr></td>
		<td class="csA4A4F90C" style="width:56px;height:19px;line-height:15px;text-align:center;vertical-align:middle;"><nobr>5</nobr></td>
		<td class="csA4A4F90C" style="width:76px;height:19px;line-height:15px;text-align:center;vertical-align:middle;"><nobr>6</nobr></td>
		<td class="csA4A4F90C" style="width:95px;height:19px;line-height:15px;text-align:center;vertical-align:middle;"><nobr>7</nobr></td>
	</tr>
	<?php	
	$tongtt =0;
	$tongttg = 0;
	foreach ($ar as $ar) 
	{
	echo "<tr style='vertical-align:top;'>";
		echo "<td style='width:0px;height:20px;'></td>";
		echo "<td class='cs5017E93Ba' style='width:75px;height:19px;line-height:15px;text-align:center;vertical-align:middle;'><nobr>".ngaythang($ar[0])."</nobr></td>";
		echo "<td class='csA4A4F90Ca' style='width:52px;height:19px;line-height:15px;text-align:center;vertical-align:middle;'><nobr></nobr></td>";
		echo "<td class='csA4A4F90Ca' style='width:75px;height:19px;line-height:15px;text-align:center;vertical-align:middle;'><nobr>".ngaythang($ar[4])."</nobr></td>";
		echo "<td class='csA4A4F90Ca' style='width:143px;height:19px;line-height:15px;text-align:left;vertical-align:middle;'><nobr>".$ar[2]."</nobr></td>";
		echo "<td class='csA4A4F90Ca' style='width:52px;height:19px;line-height:15px;text-align:center;vertical-align:middle;'><nobr>".$ar[3]."</nobr></td>";
		echo "<td class='csA4A4F90Ca' style='width:57px;height:19px;line-height:15px;text-align:center;vertical-align:middle;'><nobr>".dinhdangso($ar[5])."</nobr></td>";
		echo "<td class='csA4A4F90Ca' style='width:76px;height:19px;line-height:15px;text-align:right;vertical-align:middle;'><nobr>".dinhdangso($ar[6])."</nobr></td>";
		echo "<td class='csA4A4F90Ca' style='width:95px;height:19px;line-height:15px;text-align:right;vertical-align:middle;'><nobr>".dinhdangso($ar[7])."</nobr></td>";
		echo "<td class='csA4A4F90Ca' style='width:107px;height:19px;line-height:15px;text-align:Left;vertical-align:middle;'><nobr>".$ar[10]."</nobr></td>";
		echo "<td class='csA4A4F90Ca' style='width:56px;height:19px;line-height:15px;text-align:center;vertical-align:middle;'><nobr>".dinhdangso($ar[11])."</nobr></td>";
		echo "<td class='csA4A4F90Ca' style='width:76px;height:19px;line-height:15px;text-align:right;vertical-align:middle;'><nobr>".dinhdangso($ar[12])."</nobr></td>";
		echo "<td class='csA4A4F90Ca' style='width:95px;height:19px;line-height:15px;text-align:right;vertical-align:middle;'><nobr>".dinhdangso($ar[13])."</nobr></td>";
	echo "</tr>";	
	$tongtt += $ar[7];
	$tongttg += kieudouble($ar[13]);
	$dst = $tongtt;
	$dstg = $tongttg;
	}
	$tongtt = dinhdangso($tongtt);
	$tongttg = dinhdangso($tongttg);	
	echo "<tr style='vertical-align:top;'>";
		echo "<td style='width:0px;height:19px;'></td>";
		echo "<td class='csA96B98F9' style='width:75px;height:18px;'></td>";
		echo "<td class='cs8FC8786E' style='width:52px;height:18px;'></td>";
		echo "<td class='cs8FC8786E' style='width:75px;height:18px;'></td>";
		echo "<td class='cs8FC8786E' style='width:143px;height:18px;line-height:15px;text-align:center;vertical-align:middle;'><nobr>Tổng&nbsp;cộng</nobr></td>";
		echo "<td class='cs8FC8786E' style='width:52px;height:18px;'></td>";
		echo "<td class='cs8FC8786E' style='width:57px;height:18px;'></td>";
		echo "<td class='cs8FC8786E' style='width:76px;height:18px;'></td>";
		echo "<td class='cs8FC8786E' style='width:95px;height:18px;line-height:15px;text-align:right;vertical-align:middle;'><nobr>$tongtt</nobr></td>";
		echo "<td class='cs8FC8786E' style='width:51px;height:18px;'></td>";
		echo "<td class='cs8FC8786E' style='width:56px;height:18px;'></td>";
		echo "<td class='cs8FC8786E' style='width:76px;height:18px;'></td>";
		echo "<td class='cs8FC8786E' style='width:95px;height:18px;line-height:15px;text-align:right;vertical-align:middle;'><nobr>$tongttg</nobr></td>";
	echo "</tr>	";	
	echo "</table>";			
	?>	
	<table cellpadding="0" cellspacing="0" border="0" style="border-width:0px;empty-cells:show;">
	<tr style="vertical-align:top;">
		<td style="width:0px;height:23px;"></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td class="csCDE32A0F" colspan="5" style="width:411px;height:23px;line-height:18px;text-align:left;vertical-align:middle;"><nobr>-&nbsp;Sổ&nbsp;n&#224;y&nbsp;c&#243;&nbsp;...&nbsp;trang,&nbsp;đ&#225;nh&nbsp;số&nbsp;từ&nbsp;trang&nbsp;01&nbsp;đến&nbsp;trang&nbsp;......</nobr></td>
	</tr>
	<tr style="vertical-align:top;">
		<td style="width:0px;height:22px;"></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td class="csCDE32A0F" colspan="5" style="width:411px;height:22px;line-height:18px;text-align:left;vertical-align:top;"><nobr>-&nbsp;Ng&#224;y&nbsp;mở&nbsp;sổ:&nbsp;.....................</nobr></td>
	</tr>
	<tr style="vertical-align:top;">
		<td style="width:0px;height:2px;"></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
	</tr>
	<tr style="vertical-align:top;">
		<td style="width:0px;height:20px;"></td>
		<td class="cs6B03CC12" colspan="5" style="width:403px;height:20px;"></td>
		<td class="cs6B03CC12" colspan="5" style="width:360px;height:20px;"></td>
		<td class="cs54291A7F" colspan="4" style="width:338px;height:20px;line-height:17px;text-align:center;vertical-align:middle;"><nobr>Ng&#224;y&nbsp;.....&nbsp;th&#225;ng&nbsp;......&nbsp;năm&nbsp;.....</nobr></td>
	</tr>
	<tr style="vertical-align:top;">
		<td style="width:0px;height:19px;"></td>
		<td class="cs3D3BE940" colspan="5" style="width:403px;height:19px;line-height:17px;text-align:center;vertical-align:middle;"><nobr>Người&nbsp;ghi&nbsp;sổ</nobr></td>
		<td class="cs3D3BE940" colspan="5" style="width:360px;height:19px;line-height:17px;text-align:center;vertical-align:middle;"><nobr>Kế&nbsp;to&#225;n&nbsp;trưởng</nobr></td>
		<td class="cs3D3BE940" colspan="4" style="width:338px;height:19px;line-height:17px;text-align:center;vertical-align:middle;"><nobr>Thủ&nbsp;trưởng&nbsp;đơn&nbsp;vị</nobr></td>
	</tr>
	<tr style="vertical-align:top;">
		<td style="width:0px;height:19px;"></td>
		<td class="cs54291A7F" colspan="5" style="width:403px;height:19px;line-height:17px;text-align:center;vertical-align:middle;"><nobr>(K&#253;,&nbsp;họ&nbsp;t&#234;n)</nobr></td>
		<td class="cs54291A7F" colspan="5" style="width:360px;height:19px;line-height:17px;text-align:center;vertical-align:middle;"><nobr>(K&#253;,&nbsp;họ&nbsp;t&#234;n)</nobr></td>
		<td class="cs54291A7F" colspan="4" style="width:338px;height:19px;line-height:17px;text-align:center;vertical-align:middle;"><nobr>(K&#253;,&nbsp;họ&nbsp;t&#234;n,&nbsp;đ&#243;ng&nbsp;dấu)</nobr></td>
	</tr>
	<tr style="vertical-align:top;">
		<td style="width:0px;height:90px;"></td>
		<td class="cs3D3BE940" colspan="5" style="width:403px;height:90px;line-height:17px;text-align:center;vertical-align:bottom;"><nobr><?php echo $madv[4]; ?></nobr></td>
		<td class="cs3D3BE940" colspan="5" style="width:360px;height:90px;line-height:17px;text-align:center;vertical-align:bottom;"><nobr><?php echo $madv[5]; ?></nobr></td>
		<td class="cs3D3BE940" colspan="4" style="width:338px;height:90px;line-height:17px;text-align:center;vertical-align:bottom;"><nobr><?php echo $madv[6]; ?></nobr></td>
	</tr>
</table>
</body>
</html>