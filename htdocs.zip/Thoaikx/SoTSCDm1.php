<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
<head>
	<title>Document</title>
	<meta HTTP-EQUIV='Content-Type' CONTENT='text/html; charset=UTF-8'>
	<style type="text/css">
		.csA1694609 {color:#000000;background-color:transparent;border-left:#000000 1px solid;border-top:#000000 1px solid;border-right:#000000 1px solid;border-bottom-style: none;font-family:Times New Roman; font-size:15px; font-weight:bold; font-style:normal; }
		.csF3D1445A {color:#000000;background-color:transparent;border-left:#000000 1px solid;border-top-style: none;border-right:#000000 1px solid;border-bottom:#000000 1px solid;font-family:Times New Roman; font-size:14px; font-weight:bold; font-style:normal; }
		.csBECBE052 {color:#000000;background-color:transparent;border-left:#000000 1px solid;border-top-style: none;border-right:#000000 1px solid;border-bottom:#000000 1px solid;font-family:Times New Roman; font-size:13px; font-weight:bold; font-style:italic; }
		.cs5017E93B {color:#000000;background-color:transparent;border-left:#000000 1px solid;border-top-style: none;border-right:#000000 1px solid;border-bottom:#000000 1px solid;font-family:Times New Roman; font-size:13px; font-weight:normal; font-style:normal; }
		.cs9E02721E {color:#000000;background-color:transparent;border-left:#000000 1px solid;border-top-style: none;border-right:#000000 1px solid;border-bottom:#000000 1px solid;font-family:Times New Roman; font-size:15px; font-weight:bold; font-style:normal; }
		.cs79C72D74 {color:#000000;background-color:transparent;border-left:#000000 1px solid;border-top-style: none;border-right:#000000 1px solid;border-bottom-style: none;font-family:Times New Roman; font-size:15px; font-weight:bold; font-style:normal; }
		.csF9DCB330 {color:#000000;background-color:transparent;border-left-style: none;border-top:#000000 1px solid;border-right:#000000 1px solid;border-bottom:#000000 1px solid;font-family:Times New Roman; font-size:15px; font-weight:bold; font-style:normal; }
		.csB52C3855 {color:#000000;background-color:transparent;border-left-style: none;border-top-style: none;border-right:#000000 1px solid;border-bottom:#000000 1px solid;font-family:Times New Roman; font-size:14px; font-weight:bold; font-style:normal; }
		.csC9ADAAA1 {color:#000000;background-color:transparent;border-left-style: none;border-top-style: none;border-right:#000000 1px solid;border-bottom:#000000 1px solid;font-family:Times New Roman; font-size:14px; font-weight:bold; font-style:italic; }
		.csA4A4F90C {color:#000000;background-color:transparent;border-left-style: none;border-top-style: none;border-right:#000000 1px solid;border-bottom:#000000 1px solid;font-family:Times New Roman; font-size:14px; font-weight:normal; font-style:normal; }
		.cs3E52F49E {color:#000000;background-color:transparent;border-left-style: none;border-top-style: none;border-right:#000000 1px solid;border-bottom:#000000 1px solid;font-family:Times New Roman; font-size:15px; font-weight:bold; font-style:normal; }
		.cs265DCF67 {color:#000000;background-color:transparent;border-left-style: none;border-top-style: none;border-right:#000000 1px solid;border-bottom-style: none;font-family:Times New Roman; font-size:15px; font-weight:bold; font-style:normal; }
		.cs3D3BE940 {color:#000000;background-color:transparent;border-left-style: none;border-top-style: none;border-right-style: none;border-bottom-style: none;font-family:Times New Roman; font-size:15px; font-weight:bold; font-style:normal; }
		.cs8A77DDF0 {color:#000000;background-color:transparent;border-left-style: none;border-top-style: none;border-right-style: none;border-bottom-style: none;font-family:Times New Roman; font-size:15px; font-weight:bold; font-style:normal; padding-left:2px;padding-right:2px;}
		.cs54291A7F {color:#000000;background-color:transparent;border-left-style: none;border-top-style: none;border-right-style: none;border-bottom-style: none;font-family:Times New Roman; font-size:15px; font-weight:normal; font-style:italic; }
		.cs6B03CC12 {color:#000000;background-color:transparent;border-left-style: none;border-top-style: none;border-right-style: none;border-bottom-style: none;font-family:Times New Roman; font-size:15px; font-weight:normal; font-style:normal; }
		.cs2A8593E6 {color:#000000;background-color:transparent;border-left-style: none;border-top-style: none;border-right-style: none;border-bottom-style: none;font-family:Times New Roman; font-size:15px; font-weight:normal; font-style:normal; padding-left:2px;padding-right:2px;}
		.csB6E29E9B {color:#000000;background-color:transparent;border-left-style: none;border-top-style: none;border-right-style: none;border-bottom-style: none;font-family:Times New Roman; font-size:16px; font-weight:bold; font-style:normal; }
		.cs62AA4CC9 {color:#000000;background-color:transparent;border-left-style: none;border-top-style: none;border-right-style: none;border-bottom-style: none;font-family:Times New Roman; font-size:16px; font-weight:normal; font-style:normal; }
		.cs5DE5F832 {color:#000000;background-color:transparent;border-left-style: none;border-top-style: none;border-right-style: none;border-bottom-style: none;font-family:Times New Roman; font-size:16px; font-weight:normal; font-style:normal; padding-left:2px;padding-right:2px;}
		.cs188E5F6F {color:#000000;background-color:transparent;border-left-style: none;border-top-style: none;border-right-style: none;border-bottom-style: none;font-family:Times New Roman; font-size:24px; font-weight:bold; font-style:normal; padding-left:2px;padding-right:2px;}
		.csC88C6DB4 {color:#000000;background-color:transparent;border-left-style: none;border-top-style: none;border-right-style: none;border-bottom-style: none;font-family:Times New Roman; font-size:32px; font-weight:bold; font-style:normal; padding-left:2px;padding-right:2px;}
		.csF7D3565D {height:0px;width:0px;overflow:hidden;font-size:0px;line-height:0px;}
		 @media print {
		   .in{
			  display: none !important;
		   }
		}
	</style>
	<link rel="stylesheet" href="buttonPro.css"/>
</head>
<div class="in" style="margin-left: 1000px;">
<input  type="submit" class="buttonPro medium blue" onclick=" window.print()" value="In báo cáo"  />
<input type="button" class="buttonPro medium red" value="Thoát" onclick="window.location.href='<?php echo $_SERVER['HTTP_REFERER'];?>'" />	
</div>
<body leftMargin=10 topMargin=15 rightMargin=10 bottomMargin=15 style="background-color:#FFFFFF">
	<?php
	$phanloai = "";
	$nam = "";
	$mah ="";
	$madv ="";
	$ts5 = "No";
	$noidung="";
	if(isset($_POST['create'])){
		if ($_POST['sobg'] != "")
			$phanloai = explode('>',$_POST['sobg']);
		$nam = $_POST['nambc'];
		$mah =$_POST['huyen'];
	if(isset($_POST['ts5']))
		$ts5 = $_POST['ts5'];
		$madv = explode('>',$_POST['MADV']);	
		$msdv = $madv[0];			
	if($_POST['donvi'] != "")
		$msdv = $_POST['donvi'];
	if(isset($_POST['noidung']))
		$noidung = $_POST['noidung'];
	}
	?>
	<table cellpadding="0" cellspacing="0" border="0" style="border-width:0px;empty-cells:show;">
	<tr style="vertical-align:top;">
		<td style="width:0px;height:1px;"></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
	</tr>
	<tr style="vertical-align:top;">
		<td style="width:0px;height:2px;"></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td class="csB6E29E9B" colspan="7" rowspan="2" style="width:357px;height:24px;line-height:18px;text-align:center;vertical-align:middle;"><nobr>Mẫu&nbsp;số&nbsp;S31&nbsp;-&nbsp;H</nobr></td>
	</tr>
	<tr style="vertical-align:top;">
		<td style="width:0px;height:22px;"></td>
		<td class="cs8A77DDF0" colspan="8" style="width:470px;height:22px;line-height:17px;text-align:left;vertical-align:middle;"><nobr><?php echo $madv[3]; ?></nobr></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
	</tr>
	<tr style="vertical-align:top;">
		<td style="width:0px;height:23px;"></td>
		<td class="cs8A77DDF0" colspan="8" style="width:470px;height:23px;line-height:17px;text-align:left;vertical-align:middle;"><nobr><?php echo $madv[2]; ?></nobr></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td class="cs62AA4CC9" colspan="7" rowspan="2" style="width:357px;height:42px;line-height:18px;text-align:center;vertical-align:middle;"><nobr>(Ban&nbsp;h&#224;nh&nbsp;theo&nbsp;QĐ&nbsp;số:&nbsp;19/2006/QĐ-BTC</nobr><br/><nobr>ng&#224;y&nbsp;30/03/2006&nbsp;của&nbsp;Bộ&nbsp;trưởng&nbsp;Bộ&nbsp;T&#224;i&nbsp;Ch&#237;nh)</nobr></td>
	</tr>
	<tr style="vertical-align:top;">
		<td style="width:0px;height:19px;"></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
	</tr>
	<tr style="vertical-align:top;">
		<td style="width:0px;height:29px;"></td>
		<td class="cs188E5F6F" colspan="21" style="width:1064px;height:29px;line-height:28px;text-align:center;vertical-align:middle;"><nobr>SỔ&nbsp;T&#192;I&nbsp;SẢN&nbsp;CỐ&nbsp;ĐỊNH</nobr></td>
	</tr>
	<tr style="vertical-align:top;">
		<td style="width:0px;height:22px;"></td>
		<?php		
		echo "<td class='cs2A8593E6' colspan='21' style='width:1064px;height:22px;line-height:17px;text-align:center;vertical-align:middle;'><nobr>Năm báo cáo: $nam</nobr></td>";
		?>
	</tr>
	<tr style="vertical-align:top;">
		<td style="width:0px;height:9px;"></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
	</tr>
	</table>
	<?php
	require ("$_SERVER[DOCUMENT_ROOT]/thoaikx/general.php");
	echo "<table cellpadding='0' cellspacing='0' border='0' style='border-width:0px;empty-cells:show;'>";
	echo "<tr style='vertical-align:top; font-weight: bold;'>";
		echo "<td style='width:0px;height:23px;'></td>";
		echo "<td class='csA1694609' style='width:27px;height:22px;'></td>";
		echo "<td class='csF9DCB330' colspan='8' style='width:487px;height:21px;line-height:17px;text-align:center;vertical-align:middle;'><nobr>Ghi&nbsp;tăng&nbsp;t&#224;i&nbsp;sản&nbsp;cố&nbsp;định</nobr></td>";
		echo "<td class='csF9DCB330' colspan='8' style='width:325px;height:21px;line-height:17px;text-align:center;vertical-align:middle;'><nobr>Hao&nbsp;m&#242;n&nbsp;t&#224;i&nbsp;sản&nbsp;cố&nbsp;định</nobr></td>";
		echo "<td class='csF9DCB330' colspan='4' style='width:224px;height:21px;line-height:17px;text-align:center;vertical-align:middle;'><nobr>Ghi&nbsp;giảm&nbsp;t&#224;i&nbsp;sản&nbsp;cố&nbsp;định</nobr></td>";
	echo "</tr>";
	echo "<tr style='vertical-align:top; font-weight: bold'>";
		echo "<td style='width:0px;height:37px;'></td>";
		echo "<td class='cs79C72D74' style='width:27px;height:37px;line-height:17px;text-align:center;vertical-align:middle;'><nobr>ST</nobr><br/><nobr>T</nobr></td>";
		echo "<td class='cs265DCF67' style='width:168px;height:37px;'></td>";
		echo "<td class='cs265DCF67' style='width:49px;height:37px;line-height:17px;text-align:center;vertical-align:bottom;'><nobr>Năm</nobr></td>";
		echo "<td class='cs265DCF67' style='width:49px;height:37px;line-height:17px;text-align:center;vertical-align:bottom;'><nobr>Năm</nobr></td>";
		echo "<td class='cs265DCF67' colspan='2' style='width:84px;height:37px;'></td>";
		echo "<td class='cs265DCF67' style='width:37px;height:37px;line-height:17px;text-align:center;vertical-align:bottom;'><nobr>Số</nobr></td>";
		echo "<td class='cs265DCF67' colspan='2' style='width:95px;height:37px;'></td>";
		echo "<td class='cs3E52F49E' colspan='3' style='width:133px;height:36px;line-height:17px;text-align:center;vertical-align:middle;'><nobr>HM&nbsp;năm</nobr></td>";
		echo "<td class='cs265DCF67' colspan='4' style='width:95px;height:37px;line-height:17px;text-align:center;vertical-align:bottom;'><nobr>Số&nbsp;hao&nbsp;m&#242;n</nobr></td>";
		echo "<td class='cs265DCF67' style='width:95px;height:37px;line-height:17px;text-align:center;vertical-align:bottom;'><nobr>Lũy&nbsp;kế&nbsp;hao</nobr></td>";
		echo "<td class='cs265DCF67' style='width:89px;height:37px;line-height:17px;text-align:center;vertical-align:bottom;'><nobr>L&#253;&nbsp;do&nbsp;ghi</nobr></td>";
		echo "<td class='cs265DCF67' style='width:38px;height:37px;line-height:17px;text-align:center;vertical-align:bottom;'><nobr>Số</nobr></td>";
		echo "<td class='cs265DCF67' colspan='2' style='width:95px;height:37px;line-height:17px;text-align:center;vertical-align:bottom;'><nobr>Gi&#225;&nbsp;trị&nbsp;ghi</nobr></td>";
	echo "</tr>";
	echo "<tr style='vertical-align:top; font-weight: bold;'>";
		echo "<td style='width:0px;height:41px;'></td>";
		echo "<td class='cs9E02721E' style='width:27px;height:40px;'></td>";
		echo "<td class='cs3E52F49E' style='width:168px;height:40px;line-height:17px;text-align:center;vertical-align:top;'><nobr>T&#234;n&nbsp;gọi&nbsp;t&#224;i&nbsp;sản&nbsp;cố&nbsp;định</nobr></td>";
		echo "<td class='cs3E52F49E' style='width:49px;height:40px;line-height:17px;text-align:center;vertical-align:top;'><nobr>SX</nobr></td>";
		echo "<td class='cs3E52F49E' style='width:49px;height:40px;line-height:17px;text-align:center;vertical-align:top;'><nobr>sử</nobr><br/><nobr>dụng</nobr></td>";
		echo "<td class='cs3E52F49E' colspan='2' style='width:84px;height:40px;line-height:17px;text-align:center;vertical-align:top;'><nobr>Số&nbsp;hiệu</nobr><br/><nobr>TSCĐ</nobr></td>";
		echo "<td class='cs3E52F49E' style='width:37px;height:40px;line-height:17px;text-align:center;vertical-align:top;'><nobr>lượng</nobr></td>";
		echo "<td class='cs3E52F49E' colspan='2' style='width:95px;height:40px;line-height:17px;text-align:center;vertical-align:top;'><nobr>Nguy&#234;n&nbsp;gi&#225;</nobr></td>";
		echo "<td class='cs3E52F49E' colspan='2' style='width:37px;height:40px;line-height:17px;text-align:center;vertical-align:middle;'><nobr>Tỷ</nobr><br/><nobr>lệ&nbsp;%</nobr></td>";
		echo "<td class='cs3E52F49E' style='width:95px;height:40px;line-height:17px;text-align:center;vertical-align:middle;'><nobr>Số&nbsp;tiền</nobr></td>";
		echo "<td class='cs3E52F49E' colspan='4' style='width:95px;height:40px;line-height:17px;text-align:center;vertical-align:top;'><nobr>c&#225;c&nbsp;năm&nbsp;trước</nobr><br/><nobr>chuyển&nbsp;sang</nobr></td>";
		echo "<td class='cs3E52F49E' style='width:95px;height:40px;line-height:17px;text-align:center;vertical-align:top;'><nobr>m&#242;n&nbsp;đến</nobr><br/><nobr>khi&nbsp;ghi&nbsp;giảm</nobr></td>";
		echo "<td class='cs3E52F49E' style='width:89px;height:40px;line-height:17px;text-align:center;vertical-align:top;'><nobr>giảm&nbsp;TSCĐ</nobr><br/></td>";
		echo "<td class='cs3E52F49E' style='width:38px;height:40px;line-height:17px;text-align:center;vertical-align:top;'><nobr>lượng</nobr></td>";
		echo "<td class='cs3E52F49E' colspan='2' style='width:95px;height:40px;line-height:17px;text-align:center;vertical-align:top;'><nobr>giảm&nbsp;TSCĐ</nobr></td>";
	echo "</tr>";
	
	require ("$_SERVER[DOCUMENT_ROOT]/Main/connect.php");
	$Tsl2 = 0;
	$Tsl4 = 0;
	$Tsl5 = 0;
	$Tsl6 = 0;
	$Tsl8 = 0;
	//Lấy danh sách đơn vị
	$_sQLdv="Select distinct thongtindonvi.madonvi, thongtindonvi.tendv from tblqlts inner join thongtindonvi on tblqlts.madonvi=thongtindonvi.madonvi where tblqlts.madonvi Like '$mah%' and tblqlts.madonvi Like '$msdv%'";
	$_qdv=mysqli_query($con,$_sQLdv);
	$_aDV=array();
	while($_r=mysqli_fetch_array($_qdv)){
		$_aDV[]=array('ma'=>$_r['madonvi'],
						'ten'=>$_r['tendv']	
				);
	}
	//Duyệt từng đơn vị
	foreach($_aDV as $_madv) {
		if ($ts5 == "No") {
			$sqlts = "Select distinct tblqlts.TTQLTS,tblqlts.chitiethinhthai,tblqlts.tenchitiet,tblqlts.namsanxuat,year(ngaysudung) as nsd,tblqlts.mataisan,(DTKV+DTXD) as SL,(ngansach+nguonkhac) as NG,tblqlts.phantram" .
				" From tblqlts inner join tbldanhsachqd32 on tblqlts.chitiethinhthai = tbldanhsachqd32.chitiethinhthai" .
				" where noidung like '$noidung%' and tblqlts.madonvi = '$_madv[ma]' and ".
				" (CASE WHEN year(ngaythangchuyen) > 0 THEN year(ngaythangchuyen) <= " . $nam."  ELSE year(ngaysudung) <= " . $nam." END) ";
			if ($phanloai == "") {
				$sqlts = $sqlts . " and tblqlts.chitiethinhthai like '" . $phanloai . "%'";
			} else {
				$sqlts = $sqlts . " and (";
				$count = 0;
				$chars = str_split($_POST["sobg"]);
				foreach ($chars as &$char) {
					if ($char == '>') {
						$count++;
					}
				}
				for ($i = 0; $i < $count; $i++) {
					if ($i == $count - 1)
						$sqlts = $sqlts . "tblqlts.chitiethinhthai like '" . $phanloai[$i] . "%'";
					else
						$sqlts = $sqlts . "tblqlts.chitiethinhthai like '" . $phanloai[$i] . "%' or ";
				}
				$sqlts = $sqlts . ")";
			}
			$sqlts = $sqlts . " and tblqlts.TTQLTS not in (select TTQLTS from tbldenghi where (hinhthuc  = 'Thanh lý' or hinhthuc  = 'Điều chuyển') and year(ngaythang) < " . $nam . ") order by tbldanhsachqd32.ttsx";
		} else {
			$sqlts = "Select distinct tblqlts.TTQLTS,tblqlts.chitiethinhthai,tblqlts.tenchitiet,tblqlts.namsanxuat,year(ngaysudung) as nsd,tblqlts.mataisan,(DTKV+DTXD) as SL,(ngansach+nguonkhac) as NG,tblqlts.phantram" .
				" From tblqlts inner join tbldanhsachqd32 on tblqlts.chitiethinhthai = tbldanhsachqd32.chitiethinhthai" .
				" where noidung like '$noidung%' and (ngansach+nguonkhac) >= 500000000 and tblqlts.madonvi = '$_madv[ma]' and ".
				" (CASE WHEN year(ngaythangchuyen) > 0 THEN year(ngaythangchuyen) <= " . $nam."  ELSE year(ngaysudung) <= " . $nam." END) ";
			if ($phanloai == "") {
				$sqlts = $sqlts . " and tblqlts.chitiethinhthai like '" . $phanloai . "%'";
			} else {
				$sqlts = $sqlts . " and (";
				$count = 0;
				$chars = str_split($_POST["sobg"]);
				foreach ($chars as &$char) {
					if ($char == '>') {
						$count++;
					}
				}
				for ($i = 0; $i < $count; $i++) {
					if ($i == $count - 1)
						$sqlts = $sqlts . "tblqlts.chitiethinhthai like '" . $phanloai[$i] . "%'";
					else
						$sqlts = $sqlts . "tblqlts.chitiethinhthai like '" . $phanloai[$i] . "%' or ";
				}
				$sqlts = $sqlts . ")";
			}
			$sqlts = $sqlts . " and tblqlts.TTQLTS not in (select TTQLTS from tbldenghi where (hinhthuc  = 'Thanh lý' or hinhthuc  = 'Điều chuyển') and year(ngaythang) < " . $nam . ") order by tbldanhsachqd32.ttsx";
		}
		//echo $sqlts;
		$queryts = mysqli_query($con, $sqlts);
		$ts = array(array("A", "B", "C", "D", "E", "F", 0, 0, 0, 0, 0, 0, 0, 0));
		$cs = 0;
		$i = 0;
		$tcsl2 = 0;
		$tcsl4 = 0;
		$tcsl5 = 0;
		$tcsl6 = 0;
		$tcsl8 = 0;
		while ($rowts = mysqli_fetch_array($queryts)) {
			$tangsl = 0;
			$giamsl = 0;
			$giamtn = 0;
			$tangst = 0;
			$giamst = 0;
			$giamsttn = 0;
			$ldotg = "";
			$sltng = 0;
			$sqltg = "Select lydotanggiam,soluong,ngansach,nguonkhac,tanggiam,year(ngaytanggiam) as nam,sotien from tbltanggiam where TTQLTS = " . $rowts['TTQLTS'] . " and year(ngaytanggiam) <= " . $nam;
			$querytg = mysqli_query($con, $sqltg);
			while ($rowtg = mysqli_fetch_array($querytg)) {
				if ($rowtg['tanggiam'] == "Tăng") {
					$tangsl = $tangsl + $rowtg['soluong'];
					$tangst = $tangst + $rowtg['ngansach'] + $rowtg['nguonkhac'];
				} else {
					$giamsl = $giamsl + $rowtg['soluong'];
					$giamst = $giamst + $rowtg['sotien'];
					if($rowtg['nam'] == $nam && ($rowtg['tanggiam'] == "Thanh lý" || $rowtg['tanggiam'] == "Điều chuyển"))
					{
						$ldotg = $rowtg['lydotanggiam'];
						$giamtn += $rowtg['soluong'];
						$giamsttn += $rowtg['sotien'];
					}
				}
				if (($rowtg['tanggiam'] == "Giảm") && ($rowtg['nam'] == $nam))
					$sltng = $sltng + $rowtg['soluong'];
			}
			$haomonnam = 0;
			$sodu = 0;
			$sqlhm = "select sotien,sodu,namhaomon from tblhaomon where namhaomon <= " . $nam . " and TTQLTS = " . $rowts['TTQLTS'];
			//		echo $sqlhm;
			$queryhm = mysqli_query($con, $sqlhm);
			while ($rowhm = mysqli_fetch_array($queryhm)) {
				if ($rowhm['namhaomon'] == $nam) {
					$haomonnam = $rowhm['sotien'];
					$sodu = $rowhm['sodu'];
				} else {

					$sodu = $rowhm['sodu'] + $rowhm['sotien'];
				}
			}
			//if ($rowts['SL'] + $tangsl - $giamsl + $sltng > 0) {
				$ts[$cs][0] = $rowts['chitiethinhthai'];
				$ts[$cs][1] = $rowts['tenchitiet'];
				$ts[$cs][2] = $rowts['namsanxuat'];
				$ts[$cs][3] = $rowts['nsd'];
				$ts[$cs][4] = $rowts['mataisan'] . "." . $rowts['TTQLTS'];
				$ts[$cs][5] = $ldotg;
				$ts[$cs][6] = $rowts['SL'] + $tangsl;
				$ts[$cs][7] = $rowts['NG'] + $tangst;
				$ts[$cs][12] = $giamtn;
				$ts[$cs][13] = $giamsttn;
				$ts[$cs][8] = $rowts['phantram'];
				$ts[$cs][9] = $haomonnam;
				$ts[$cs][10] = $sodu;
				$ts[$cs][11] = $haomonnam + $sodu;
				$cs = $cs + 1;
				$tcsl2 = $tcsl2 + $rowts['NG'] + $tangst;
				$tcsl4 = $tcsl4 + $haomonnam;
				$tcsl5 = $tcsl5 + $sodu;
				$tcsl6 = $tcsl6 + $haomonnam + $sodu;
				$tcsl8 = $tcsl8 + $giamsttn;
				$Tsl2 +=  $rowts['NG'] + $tangst;
				$Tsl4 += $haomonnam;
				$Tsl5 += $sodu;
				$Tsl6 += $haomonnam + $sodu;
				$Tsl8 += $giamsttn;
			//}
		}
		$nhomsl2 = 0;
		$nhomsl4 = 0;
		$nhomsl5 = 0;
		$nhomsl6 = 0;
		$nhomsl8 = 0;
		$j = 0;
		$tennhomsau = "";
		$tennhom = "";
		$stt = 0;
		//Tên đơn vị
		echo "<tr style='vertical-align:top;'>";
		echo "<td style='width:0px;height:23px'></td>";
		echo "<td class='csC9ADAAA1' colspan='21' style='border-left:#000000 1px solid;vertical-align:middle;'>"; if($noidung != "") echo $noidung; else echo $_madv['ten'];  echo "</td>";
		echo "</tr>";

		for ($i = 0; $i < $cs; $i++) {
			$stt++;
			$tennhom = $ts[$i][0];
			$ten1 = $ts[$i][1];
			$ten2 = $ts[$i][2];
			$ten3 = $ts[$i][3];
			$ten4 = $ts[$i][4];
			$ten5 = $ts[$i][5];
			//$sl1=$ts[$i][6];$sl2=dinhdangso($ts[$i][7]);$sl3=$ts[$i][8];$sl4=dinhdangso($ts[$i][9]);$sl5=dinhdangso($ts[$i][10]);$sl6=dinhdangso($ts[$i][11]);$sl7=dinhdangso($ts[$i][12]);$sl8=dinhdangso($ts[$i][13]);
			//$sl1=$ts[$i][6];$sl2=dinhdangso($ts[$i][7]);$sl3=$ts[$i][8];$sl4=dinhdangso($ts[$i][8]*$ts[$i][7]/100);$sl5=dinhdangso($ts[$i][10]);$sl6=dinhdangso($ts[$i][11]);$sl7=dinhdangso($ts[$i][12]);$sl8=dinhdangso($ts[$i][13]);
			$sl1 = $ts[$i][6];
			$sl2 = dinhdangso($ts[$i][7]);
			$sl3 = $ts[$i][8];
			$sl4 = dinhdangso($ts[$i][9]);
			$sl5 = dinhdangso($ts[$i][10]);
			$sl6 = dinhdangso($ts[$i][11]);
			$sl7 = dinhdangso($ts[$i][12]);
			$sl8 = dinhdangso($ts[$i][13]);
			if ($tennhom != $tennhomsau) {
				//nhóm group
				$nhomsl2 = 0;
				$nhomsl4 = 0;
				$nhomsl5 = 0;
				$nhomsl6 = 0;
				$nhomsl8 = 0;
				$j = 0;
				for ($j = 0; $j < $cs; $j++) {
					if ($ts[$j][0] == $tennhom) {
						$nhomsl2 = $nhomsl2 + $ts[$j][7];
						$nhomsl4 = $nhomsl4 + $ts[$j][9];
						$nhomsl5 = $nhomsl5 + $ts[$j][10];
						$nhomsl6 = $nhomsl6 + $ts[$j][11];
						$nhomsl8 = $nhomsl8 + $ts[$j][13];
					}
				}
				$nhomsl2 = dinhdangso($nhomsl2);
				$nhomsl4 = dinhdangso($nhomsl4);
				$nhomsl5 = dinhdangso($nhomsl5);
				$nhomsl6 = dinhdangso($nhomsl6);
				$nhomsl8 = dinhdangso($nhomsl8);
				echo "<tr style='vertical-align:top;'>";
				echo "<td style='width:0px;height:23px;'></td>";
				echo "<td class='csBECBE052' style='width:27px;height:22px;'></td>";
				echo "<td class='csC9ADAAA1' colspan='5' style='width:353px;height:22px;line-height:15px;text-align:left;vertical-align:middle;'><nobr>$tennhom</nobr></td>";
				echo "<td class='csC9ADAAA1' style='width:37px;height:22px;'></td>";
				echo "<td class='csC9ADAAA1' colspan='2' style='width:95px;height:22px;line-height:15px;text-align:right;vertical-align:middle;'><nobr>$nhomsl2</nobr></td>";
				echo "<td class='csC9ADAAA1' colspan='2' style='width:37px;height:22px;'></td>";
				echo "<td class='csC9ADAAA1' style='width:95px;height:22px;line-height:15px;text-align:right;vertical-align:middle;'><nobr>$nhomsl4</nobr></td>";
				echo "<td class='csC9ADAAA1' colspan='4' style='width:95px;height:22px;line-height:15px;text-align:right;vertical-align:middle;'><nobr>$nhomsl5</nobr></td>";
				echo "<td class='csC9ADAAA1' style='width:95px;height:22px;line-height:15px;text-align:right;vertical-align:middle;'><nobr>$nhomsl6</nobr></td>";
				echo "<td class='csC9ADAAA1' style='width:89px;height:22px;'></td>";
				echo "<td class='csC9ADAAA1' style='width:38px;height:22px;'></td>";
				echo "<td class='csC9ADAAA1' colspan='2' style='width:95px;height:22px;line-height:15px;text-align:right;vertical-align:middle;'><nobr>$nhomsl8</nobr></td>";
				echo "</tr>";
			}
			// chi tiết
			echo "<tr style='vertical-align:top;'>";
			echo "<td style='width:0px;height:23px;'></td>";
			echo "<td class='cs5017E93B' style='width:27px;height:22px;line-height:15px;text-align:center;vertical-align:middle;'><nobr>$stt</nobr></td>";
			echo "<td class='csA4A4F90C' style='width:168px;height:22px;line-height:15px;text-align:left;vertical-align:middle;'><nobr>$ten1</nobr></td>";
			echo "<td class='csA4A4F90C' style='width:49px;height:22px;line-height:15px;text-align:center;vertical-align:middle;'><nobr>$ten2</nobr></td>";
			echo "<td class='csA4A4F90C' style='width:49px;height:22px;line-height:15px;text-align:center;vertical-align:middle;'><nobr>$ten3</nobr></td>";
			echo "<td class='csA4A4F90C' colspan='2' style='width:84px;height:22px;line-height:15px;text-align:center;vertical-align:middle;'><nobr>$ten4</nobr></td>";
			echo "<td class='csA4A4F90C' style='width:37px;height:22px;line-height:15px;text-align:center;vertical-align:middle;'><nobr>$sl1</nobr></td>";
			echo "<td class='csA4A4F90C' colspan='2' style='width:95px;height:22px;line-height:15px;text-align:right;vertical-align:middle;'><nobr>$sl2</nobr></td>";
			echo "<td class='csA4A4F90C' colspan='2' style='width:37px;height:22px;line-height:15px;text-align:center;vertical-align:middle;'><nobr>$sl3</nobr></td>";
			echo "<td class='csA4A4F90C' style='width:95px;height:22px;line-height:15px;text-align:right;vertical-align:middle;'><nobr>$sl4</nobr></td>";
			echo "<td class='csA4A4F90C' colspan='4' style='width:95px;height:22px;line-height:15px;text-align:right;vertical-align:middle;'><nobr>$sl5</nobr></td>";
			echo "<td class='csA4A4F90C' style='width:95px;height:22px;line-height:15px;text-align:right;vertical-align:middle;'><nobr>$sl6</nobr></td>";
			echo "<td class='csA4A4F90C' style='width:89px;height:22px;line-height:15px;text-align:right;vertical-align:middle;'><nobr>$ten5</nobr></td>";
			echo "<td class='csA4A4F90C' style='width:38px;height:22px;line-height:15px;text-align:center;vertical-align:middle;'><nobr>$sl7</nobr></td>";
			echo "<td class='csA4A4F90C' colspan='2' style='width:95px;height:22px;line-height:15px;text-align:right;vertical-align:middle;'><nobr>$sl8</nobr></td>";
			echo "</tr>";
			$tennhomsau = $ts[$i][0];
		}
		// tổng cộng
		$tcsl2 = dinhdangso($tcsl2);
		$tcsl4 = dinhdangso($tcsl4);
		$tcsl5 = dinhdangso($tcsl5);
		$tcsl6 = dinhdangso($tcsl6);
		$tcsl8 = dinhdangso($tcsl8);
		echo "<tr style='vertical-align:top;'>";
		echo "<td style='width:0px;height:23px;'></td>";
		echo "<td class='csF3D1445A' style='width:27px;height:22px;'></td>";
		echo "<td class='csB52C3855' style='width:168px;height:22px;line-height:13px;text-align:center;vertical-align:middle;'><nobr>Cộng</nobr></td>";
		echo "<td class='csB52C3855' style='width:49px;height:22px;line-height:13px;text-align:center;vertical-align:middle;'><nobr>X</nobr></td>";
		echo "<td class='csB52C3855' style='width:49px;height:22px;line-height:13px;text-align:center;vertical-align:middle;'><nobr>X</nobr></td>";
		echo "<td class='csB52C3855' colspan='2' style='width:84px;height:22px;line-height:13px;text-align:center;vertical-align:middle;'><nobr>X</nobr></td>";
		echo "<td class='csB52C3855' style='width:37px;height:22px;line-height:13px;text-align:center;vertical-align:middle;'><nobr>X</nobr></td>";
		echo "<td class='csB52C3855' colspan='2' style='width:95px;height:22px;line-height:13px;text-align:right;vertical-align:middle;'><nobr>$tcsl2</nobr></td>";
		echo "<td class='csB52C3855' colspan='2' style='width:37px;height:22px;line-height:13px;text-align:center;vertical-align:middle;'><nobr>X</nobr></td>";
		echo "<td class='csB52C3855' style='width:95px;height:22px;line-height:13px;text-align:right;vertical-align:middle;'><nobr>$tcsl4</nobr></td>";
		echo "<td class='csB52C3855' colspan='4' style='width:95px;height:22px;line-height:13px;text-align:right;vertical-align:middle;'><nobr>$tcsl5</nobr></td>";
		echo "<td class='csB52C3855' style='width:95px;height:22px;line-height:13px;text-align:right;vertical-align:middle;'><nobr>$tcsl6</nobr></td>";
		echo "<td class='csB52C3855' style='width:89px;height:22px;line-height:13px;text-align:center;vertical-align:middle;'><nobr>X</nobr></td>";
		echo "<td class='csB52C3855' style='width:38px;height:22px;line-height:13px;text-align:center;vertical-align:middle;'><nobr>X</nobr></td>";
		echo "<td class='csB52C3855' colspan='2' style='width:95px;height:22px;line-height:13px;text-align:right;vertical-align:middle;'><nobr>$tcsl8</nobr></td>";
		echo "</tr>";
	}
	$Tsl2 = dinhdangso($Tsl2);
	$Tsl4 = dinhdangso($Tsl4);
	$Tsl5 = dinhdangso($Tsl5);
	$Tsl6 = dinhdangso($Tsl6);
	$Tsl8 = dinhdangso($Tsl8);
	echo "<tr style='vertical-align:top;'>";
	echo "<td style='width:0px;height:23px;'></td>";
	echo "<td class='csF3D1445A' style='width:27px;height:22px;'></td>";
	echo "<td class='csB52C3855' style='width:168px;height:22px;line-height:13px;text-align:center;vertical-align:middle;'><nobr>Tổng cộng</nobr></td>";
	echo "<td class='csB52C3855' style='width:49px;height:22px;line-height:13px;text-align:center;vertical-align:middle;'><nobr>X</nobr></td>";
	echo "<td class='csB52C3855' style='width:49px;height:22px;line-height:13px;text-align:center;vertical-align:middle;'><nobr>X</nobr></td>";
	echo "<td class='csB52C3855' colspan='2' style='width:84px;height:22px;line-height:13px;text-align:center;vertical-align:middle;'><nobr>X</nobr></td>";
	echo "<td class='csB52C3855' style='width:37px;height:22px;line-height:13px;text-align:center;vertical-align:middle;'><nobr>X</nobr></td>";
	echo "<td class='csB52C3855' colspan='2' style='width:95px;height:22px;line-height:13px;text-align:right;vertical-align:middle;'><nobr>$Tsl2</nobr></td>";
	echo "<td class='csB52C3855' colspan='2' style='width:37px;height:22px;line-height:13px;text-align:center;vertical-align:middle;'><nobr>X</nobr></td>";
	echo "<td class='csB52C3855' style='width:95px;height:22px;line-height:13px;text-align:right;vertical-align:middle;'><nobr>$Tsl4</nobr></td>";
	echo "<td class='csB52C3855' colspan='4' style='width:95px;height:22px;line-height:13px;text-align:right;vertical-align:middle;'><nobr>$Tsl5</nobr></td>";
	echo "<td class='csB52C3855' style='width:95px;height:22px;line-height:13px;text-align:right;vertical-align:middle;'><nobr>$Tsl6</nobr></td>";
	echo "<td class='csB52C3855' style='width:89px;height:22px;line-height:13px;text-align:center;vertical-align:middle;'><nobr>X</nobr></td>";
	echo "<td class='csB52C3855' style='width:38px;height:22px;line-height:13px;text-align:center;vertical-align:middle;'><nobr>X</nobr></td>";
	echo "<td class='csB52C3855' colspan='2' style='width:95px;height:22px;line-height:13px;text-align:right;vertical-align:middle;'><nobr>$Tsl8</nobr></td>";
	echo "</tr>";
	echo "</table>";
	?>
	<table cellpadding="0" cellspacing="0" border="0" style="border-width:0px;empty-cells:show;">
	<tr style="vertical-align:top;">
		<td style="width:0px;height:22px;"></td>
		<td colspan=12></td>		
		<td class="cs2A8593E6" colspan="9" style="width:413px;height:22px;line-height:17px;text-align:left;vertical-align:middle;"><nobr></nobr></td>
	</tr>
	<tr style="vertical-align:top;">
		<td style="width:0px;height:21px;"></td>
		<td class="cs6B03CC12" colspan="5" style="width:356px;height:21px;"></td>
		<td class="cs6B03CC12" colspan="10" style="width:356px;height:21px;"></td>
		<td class="cs6B03CC12" colspan="6" style="width:356px;height:21px;line-height:17px;text-align:center;vertical-align:middle;font-style:italic;"><nobr><?php echo $madv[7].', ngày ... tháng ... năm ......'; ?></nobr></td>
	</tr>
	<tr style="vertical-align:top;">
		<td style="width:0px;height:21px;"></td>
		<td class="cs3D3BE940" colspan="5" style="width:356px;height:21px;line-height:17px;text-align:center;vertical-align:middle;"><nobr>Người&nbsp;ghi&nbsp;sổ</nobr></td>
		<td class="cs3D3BE940" colspan="10" style="width:356px;height:21px;line-height:17px;text-align:center;vertical-align:middle;"><nobr>Kế&nbsp;to&#225;n&nbsp;trưởng</nobr></td>
		<td class="cs3D3BE940" colspan="6" style="width:356px;height:21px;line-height:17px;text-align:center;vertical-align:middle;"><nobr>Thủ&nbsp;trưởng&nbsp;đơn&nbsp;vị</nobr></td>
	</tr>
	<tr style="vertical-align:top;">
		<td style="width:0px;height:21px;"></td>
		<td class="cs54291A7F" colspan="5" style="width:356px;height:21px;line-height:17px;text-align:center;vertical-align:middle;"><nobr>(K&#253;,&nbsp;họ&nbsp;t&#234;n)</nobr></td>
		<td class="cs54291A7F" colspan="10" style="width:356px;height:21px;line-height:17px;text-align:center;vertical-align:middle;"><nobr>(K&#253;,&nbsp;họ&nbsp;t&#234;n)</nobr></td>
		<td class="cs54291A7F" colspan="6" style="width:356px;height:21px;line-height:17px;text-align:center;vertical-align:middle;"><nobr>(K&#253;,&nbsp;họ&nbsp;t&#234;n,&nbsp;đ&#243;ng&nbsp;dấu)</nobr></td>
	</tr>
		<tr style="vertical-align:top;height: 50px;">
			<td ></td>
			<td ></td>
			<td ></td>
			<td ></td>
		</tr>
	<tr style="vertical-align:top;">
		<td style="width:0px;height:84px;"></td>
		<td class="cs3D3BE940" colspan="5" style="width:356px;height:84px;line-height:17px;text-align:center;vertical-align:bottom;"><nobr><?php echo $madv[4]; ?></nobr></td>
		<td class="cs3D3BE940" colspan="10" style="width:356px;height:84px;line-height:17px;text-align:center;vertical-align:bottom;"><nobr><?php echo $madv[5]; ?></nobr></td>
		<td class="cs3D3BE940" colspan="6" style="width:356px;height:84px;line-height:17px;text-align:center;vertical-align:bottom;"><nobr><?php echo $madv[6]; ?></nobr></td>
	</tr>
</table>
</body>
</html>