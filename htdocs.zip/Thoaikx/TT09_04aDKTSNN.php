﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
<head>
	<title>Document</title>
	<meta HTTP-EQUIV='Content-Type' CONTENT='text/html; charset=utf-8'>
	<style type="text/css">
		.cs275E312D {color:#000000;background-color:transparent;border-left:#000000 1px solid;border-top:#000000 1px solid;border-right:#000000 1px solid;border-bottom:#000000 1px solid;font-family:Times New Roman; font-size:13px; font-weight:bold; font-style:normal; }
		.cs5017E93B {color:#000000;background-color:transparent;border-left:#000000 1px solid;border-top-style: none;border-right:#000000 1px solid;border-bottom:#000000 1px solid;font-family:Times New Roman; font-size:13px; font-weight:normal; font-style:normal; }
		.csAB3AA82A {color:#000000;background-color:transparent;border-left-style: none;border-top:#000000 1px solid;border-right:#000000 1px solid;border-bottom:#000000 1px solid;font-family:Times New Roman; font-size:13px; font-weight:bold; font-style:normal; }
		.csA4A4F90C {color:#000000;background-color:transparent;border-left-style: none;border-top-style: none;border-right:#000000 1px solid;border-bottom:#000000 1px solid;font-family:Times New Roman; font-size:13px; font-weight:normal; font-style:normal; }
		.csB6E29E9B {color:#000000;background-color:transparent;border-left-style: none;border-top-style: none;border-right-style: none;border-bottom-style: none;font-family:Times New Roman; font-size:16px; font-weight:bold; font-style:normal; }
		.cs77A39B34 {color:#000000;background-color:transparent;border-left-style: none;border-top-style: none;border-right-style: none;border-bottom-style: none;font-family:Times New Roman; font-size:16px; font-weight:normal; font-style:italic; }
		.cs62AA4CC9 {color:#000000;background-color:transparent;border-left-style: none;border-top-style: none;border-right-style: none;border-bottom-style: none;font-family:Times New Roman; font-size:16px; font-weight:normal; font-style:normal; }
		.csDC8759AC {color:#000000;background-color:transparent;border-left-style: none;border-top-style: none;border-right-style: none;border-bottom-style: none;font-family:Times New Roman; font-size:19px; font-weight:bold; font-style:normal; }
		.csF7D3565D {height:0px;width:0px;overflow:hidden;font-size:0px;line-height:0px;}
	</style>
</head>
<body leftMargin=10 topMargin=10 rightMargin=10 bottomMargin=10 style="background-color:#FFFFFF">
<table cellpadding="0" cellspacing="0" border="0" style="border-width:0px;empty-cells:show;width:1044px;height:590px;">
	<tr>
		<td style="width:0px;height:0px;"></td>
		<td style="height:0px;width:47px;"></td>
		<td style="height:0px;width:124px;"></td>
		<td style="height:0px;width:175px;"></td>
		<td style="height:0px;width:136px;"></td>
		<td style="height:0px;width:30px;"></td>
		<td style="height:0px;width:5px;"></td>
		<td style="height:0px;width:138px;"></td>
		<td style="height:0px;width:65px;"></td>
		<td style="height:0px;width:107px;"></td>
		<td style="height:0px;width:207px;"></td>
		<td style="height:0px;width:10px;"></td>
	</tr>
	<tr style="vertical-align:top;">
		<td style="width:0px;height:20px;"></td>
		<td class="csB6E29E9B" colspan="2" style="width:171px;height:20px;line-height:18px;text-align:left;vertical-align:middle;"><nobr>Bộ,&nbsp;tỉnh:</nobr></td>
		<td class="csB6E29E9B" colspan="2" style="width:311px;height:20px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
		<td colspan="3"></td>
		<td class="csB6E29E9B" colspan="4" style="width:389px;height:20px;line-height:18px;text-align:center;vertical-align:middle;"><nobr>Mẫu&nbsp;số&nbsp;04a-ĐK/TSNN</nobr></td>
	</tr>
	<tr style="vertical-align:top;">
		<td style="width:0px;height:20px;"></td>
		<td class="csB6E29E9B" colspan="2" style="width:171px;height:20px;line-height:18px;text-align:left;vertical-align:middle;"><nobr>Đơn&nbsp;vị&nbsp;chủ&nbsp;quản:</nobr></td>
		<td class="csB6E29E9B" colspan="2" style="width:311px;height:20px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
		<td colspan="3"></td>
		<td class="cs62AA4CC9" colspan="4" rowspan="2" style="width:389px;height:40px;line-height:18px;text-align:center;vertical-align:middle;"><nobr>(Ban&nbsp;h&#224;nh&nbsp;theo&nbsp;Th&#244;ng&nbsp;tư&nbsp;số&nbsp;09/2012/TT-BTC</nobr><br/><nobr>ng&#224;y&nbsp;19/01/2012&nbsp;của&nbsp;Bộ&nbsp;t&#224;i&nbsp;ch&#237;nh)</nobr></td>
	</tr>
	<tr style="vertical-align:top;">
		<td style="width:0px;height:20px;"></td>
		<td class="csB6E29E9B" colspan="2" style="width:171px;height:20px;line-height:18px;text-align:left;vertical-align:middle;"><nobr>Đơn&nbsp;vị&nbsp;sử&nbsp;dụng&nbsp;t&#224;i&nbsp;sản:</nobr></td>
		<td class="csB6E29E9B" colspan="2" style="width:311px;height:20px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
		<td colspan="3"></td>		
	</tr>
	<tr style="vertical-align:top;">
		<td style="width:0px;height:21px;"></td>
		<td class="csB6E29E9B" colspan="2" style="width:171px;height:21px;line-height:18px;text-align:left;vertical-align:middle;"><nobr>M&#227;&nbsp;đơn&nbsp;vị:</nobr></td>
		<td class="csB6E29E9B" colspan="2" style="width:311px;height:21px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
	</tr>
	<tr style="vertical-align:top;">
		<td style="width:0px;height:20px;"></td>
		<td class="csB6E29E9B" colspan="2" style="width:171px;height:20px;line-height:18px;text-align:left;vertical-align:middle;"><nobr>Loại&nbsp;h&#236;nh&nbsp;đơn&nbsp;vị:</nobr></td>
		<td class="csB6E29E9B" colspan="2" style="width:311px;height:20px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
	</tr>				
	<tr style="vertical-align:top;">
		<td style="width:0px;height:11px;"></td>		
	</tr>
	<tr style="vertical-align:top;">
		<td style="width:0px;height:49px;"></td>
		<td class="csDC8759AC" colspan="11" style="width:1044px;height:49px;line-height:22px;text-align:center;vertical-align:middle;"><nobr>B&#193;O&nbsp;C&#193;O&nbsp;K&#202;&nbsp;KHAI</nobr><br/><nobr>THAY&nbsp;ĐỔI&nbsp;TH&#212;NG&nbsp;TIN&nbsp;VỀ&nbsp;ĐƠN&nbsp;VỊ&nbsp;SỬ&nbsp;DỤNG&nbsp;T&#192;I&nbsp;SẢN</nobr></td>
	</tr>
	<tr style="vertical-align:top;">
		<td style="width:0px;height:10px;"></td>		
	</tr>
	<!-- từ đây -->
	<?php	
		$tungay = "";
		$denngay = "";		
		if(isset($_POST['create'])){
			$tungay = $_POST['nttu'];
			$denngay = $_POST['ntden'];	
			$madv = explode('>',$_POST['MADV']);				
		}
		
		function sapxep($in_bike1, $in_bike2){
			 if ($in_bike1["ngaythang"] > $in_bike2["ngaythang"]){ 
				return 1; 
			} 
			else if ($in_bike1["ngaythang"] == $in_bike2["ngaythang"]){ 
				return 0; 
			} 
			else { 
				return -1; 
			} 
		}
		
		function ngaythang($ngay){
			   $kq ="";
			   if($ngay!="")   
				$kq = substr($ngay,8,2)."/". substr($ngay,5,2) . "/".substr($ngay,0,4)  ;  
			   return $kq;
  		}
	
		function doingay($ngay)
		{
			$kq = substr($ngay,6,4) ."/". substr($ngay,3,2) . "/". substr($ngay,0,2);		
			return $kq;
		}
		
		function dinhdangso($so)
		{
			$kq = "";
			if ($so > 0)
				$kq = number_format($so);
			return $kq;	
		}
		
		function kieudouble($so)
		{
			$kq = 0;
			if ($so != "")
				$kq = (double)$so;
			else
				$kq = 0;	
			return $kq;	
		}		
		require("$_SERVER[DOCUMENT_ROOT]/Main/connect.php");	 
		$cs=0;$ton=0;
		$cc=array();
		$sqlcc = "Select NTTD, CTTD, TTKK, TTTD, LDTD, madonvi from tblthaydoi where   NTTD between '". doingay($tungay)."' and '".doingay($denngay). "' order by NTTD";
		$querycc=mysqli_query($con,$sqlcc);
		while($rowcc=mysqli_fetch_array($querycc)){			
			$cc[$cs]=array("NTTD"=> $rowcc['NTTD'],
							"CTTD"=>$rowcc['CTTD'],
							"TTKK"=>$rowcc['TTKK'],
							"TTTD"=>$rowcc['TTTD'],
							"LDTD"=>$rowcc['LDTD'],
							"madonvi"=>$rowcc['madonvi']);			
			$cs++;
		}
		
		function searchForId($ct, $mdv, $array, $col) {			 
		   foreach($array as $value)
		   {		   		
				if($value['madonvi']== $mdv && $value['CTTD']==$ct){
						return $value[$col];				
				}
		   }
		   return null;		   
		}
		$aMaDV=array();
		foreach($cc as $col){
			if(!in_array($col['madonvi'],$aMaDV)){
				array_push($aMaDV,$col['madonvi']);
			}
		}
		foreach($aMaDV as $col){	
			echo "<tr style='vertical-align:top;'>";
				echo "<td style='width:0px;height:37px;'></td>";
				echo "<td class='cs275E312D' style='width:45px;height:35px;line-height:15px;text-align:center;vertical-align:middle;'><nobr>STT</nobr></td>";
				echo "<td class='csAB3AA82A' colspan='2' style='width:298px;height:35px;line-height:15px;text-align:center;vertical-align:middle;'><nobr>CHỈ&nbsp;TI&#202;U</nobr></td>";
				echo "<td class='csAB3AA82A' colspan='2' style='width:165px;height:35px;line-height:15px;text-align:center;vertical-align:middle;'><nobr>TH&#212;NG&nbsp;TIN&nbsp;Đ&#195;&nbsp;K&#202;&nbsp;KHAI</nobr></td>";
				echo "<td class='csAB3AA82A' colspan='3' style='width:207px;height:35px;line-height:15px;text-align:center;vertical-align:middle;'><nobr>TH&#212;NG&nbsp;TIN&nbsp;ĐỀ&nbsp;NGHỊ&nbsp;THAY&nbsp;ĐỔI</nobr></td>";
				echo "<td class='csAB3AA82A' style='width:106px;height:35px;line-height:15px;text-align:center;vertical-align:middle;'><nobr>NG&#192;Y&nbsp;TH&#193;NG</nobr><br/><nobr>THAY&nbsp;ĐỔI</nobr></td>";
				echo "<td class='csAB3AA82A' colspan='2' style='width:216px;height:35px;line-height:15px;text-align:center;vertical-align:middle;'><nobr>L&#221;&nbsp;DO&nbsp;THAY&nbsp;ĐỔI</nobr></td>";
			echo "</tr>";
			echo "<tr style='vertical-align:top;'>";
				echo "<td style='width:0px;height:24px;'></td>";
				echo "<td class='cs5017E93B' style='width:45px;height:23px;line-height:15px;text-align:center;vertical-align:middle;'><nobr>1</nobr></td>";
				echo "<td class='csA4A4F90C' colspan='2' style='width:298px;height:23px;line-height:15px;text-align:left;vertical-align:middle;'><nobr>&nbsp;M&#227;&nbsp;đơn&nbsp;vị&nbsp;QHNS</nobr></td>";
				echo "<td class='csA4A4F90C' colspan='2' style='width:165px;height:23px;;line-height:15px;text-align:left;vertical-align:middle;'><nobr>".searchForId("Mã đơn vị QHNS",$col,$cc,"TTKK")."</nobr></td>";
				echo "<td class='csA4A4F90C' colspan='3' style='width:207px;height:23px;'><nobr>".searchForId("Mã đơn vị QHNS",$col,$cc,"TTTD")."</nobr></td>";
				echo "<td class='csA4A4F90C' style='width:106px;height:23px;text-align:center;vertical-align:middle;'><nobr>".ngaythang(searchForId("Mã đơn vị QHNS",$col,$cc,"NTTD"))."</nobr></td>";
				echo "<td class='csA4A4F90C' colspan='2' style='width:216px;height:23px;'><nobr>".searchForId("Mã đơn vị QHNS",$col,$cc,"LDTD")."</nobr></td>";
			echo "</tr>";
			echo "<tr style='vertical-align:top;'>";
				echo "<td style='width:0px;height:24px;'></td>";
				echo "<td class='cs5017E93B' style='width:45px;height:23px;line-height:15px;text-align:center;vertical-align:middle;'><nobr>2</nobr></td>";
				echo "<td class='csA4A4F90C' colspan='2' style='width:298px;height:23px;line-height:15px;text-align:left;vertical-align:middle;'><nobr>&nbsp;T&#234;n&nbsp;đơn&nbsp;vị</nobr></td>";
				echo "<td class='csA4A4F90C' colspan='2' style='width:165px;height:23px;'><nobr>".searchForId("Tên đơn vị",$col,$cc,"TTKK")."</nobr></td>";
				echo "<td class='csA4A4F90C' colspan='3' style='width:207px;height:23px;'><nobr>".searchForId("Tên đơn vị",$col,$cc,"TTTD")."</nobr></td>";
				echo "<td class='csA4A4F90C' style='width:106px;height:23px;text-align:center;vertical-align:middle;'><nobr>".ngaythang(searchForId("Tên đơn vị",$col,$cc,"NTTD"))."</nobr></td>";
				echo "<td class='csA4A4F90C' colspan='2' style='width:216px;height:23px;'><nobr>".searchForId("Tên đơn vị",$col,$cc,"LDTD")."</nobr></td>";
			echo "</tr>";
			echo "<tr style='vertical-align:top;'>";
				echo "<td style='width:0px;height:24px;'></td>";
				echo "<td class='cs5017E93B' style='width:45px;height:23px;line-height:15px;text-align:center;vertical-align:middle;'><nobr>3</nobr></td>";
				echo "<td class='csA4A4F90C' colspan='2' style='width:298px;height:23px;line-height:15px;text-align:left;vertical-align:middle;'><nobr>&nbsp;Đơn&nbsp;vị&nbsp;chủ&nbsp;quản</nobr></td>";
				echo "<td class='csA4A4F90C' colspan='2' style='width:165px;height:23px;'><nobr>".searchForId("Đơn vị chủ quản",$col,$cc,"TTKK")."</nobr></td>";
				echo "<td class='csA4A4F90C' colspan='3' style='width:207px;height:23px;'><nobr>".searchForId("Đơn vị chủ quản",$col,$cc,"TTTD")."</nobr></td>";
				echo "<td class='csA4A4F90C' style='width:106px;height:23px;text-align:center;vertical-align:middle;'><nobr>".ngaythang(searchForId("Đơn vị chủ quản",$col,$cc,"NTTD"))."</nobr></td>";
				echo "<td class='csA4A4F90C' colspan='2' style='width:216px;height:23px;'><nobr>".searchForId("Đơn vị chủ quản",$col,$cc,"LDTD")."</nobr></td>";
			echo "</tr>";
			echo "<tr style='vertical-align:top;'>";
				echo "<td style='width:0px;height:24px;'></td>";
				echo "<td class='cs5017E93B' style='width:45px;height:23px;line-height:15px;text-align:center;vertical-align:middle;'><nobr>4</nobr></td>";
				echo "<td class='csA4A4F90C' colspan='2' style='width:298px;height:23px;line-height:15px;text-align:left;vertical-align:middle;'><nobr>&nbsp;Địa&nbsp;chỉ</nobr></td>";
				echo "<td class='csA4A4F90C' colspan='2' style='width:165px;height:23px;'><nobr>".searchForId("Địa chỉ",$col,$cc,"TTKK")."</nobr></td>";
				echo "<td class='csA4A4F90C' colspan='3' style='width:207px;height:23px;'><nobr>".searchForId("Địa chỉ",$col,$cc,"TTTD")."</nobr></td>";
				echo "<td class='csA4A4F90C' style='width:106px;height:23px;text-align:center;vertical-align:middle;'><nobr>".ngaythang(searchForId("Địa chỉ",$col,$cc,"NTTD"))."</nobr></td>";
				echo "<td class='csA4A4F90C' colspan='2' style='width:216px;height:23px;'><nobr>".searchForId("Địa chỉ",$col,$cc,"LDTD")."</nobr></td>";
			echo "</tr>";
			echo "<tr style='vertical-align:top;'>";
				echo "<td style='width:0px;height:24px;'></td>";
				echo "<td class='cs5017E93B' style='width:45px;height:23px;line-height:15px;text-align:center;vertical-align:middle;'><nobr>5</nobr></td>";
				echo "<td class='csA4A4F90C' colspan='2' style='width:298px;height:23px;line-height:15px;text-align:left;vertical-align:middle;'><nobr>&nbsp;Thuộc&nbsp;loại&nbsp;(đơn&nbsp;vị&nbsp;tổng&nbsp;hợp/đơn&nbsp;vị&nbsp;đăng&nbsp;k&#253;)</nobr></td>";
				echo "<td class='csA4A4F90C' colspan='2' style='width:165px;height:23px;'><nobr>".searchForId("Thuộc loại (Đơn vị tổng hợp/ Đơn vị đăng ký)",$col,$cc,"TTKK")."</nobr></td>";
				echo "<td class='csA4A4F90C' colspan='3' style='width:207px;height:23px;'><nobr>".searchForId("Thuộc loại (Đơn vị tổng hợp/ Đơn vị đăng ký)",$col,$cc,"TTTD")."</nobr></td>";
				echo "<td class='csA4A4F90C' style='width:106px;height:23px;text-align:center;vertical-align:middle;'><nobr>".ngaythang(searchForId("Thuộc loại (Đơn vị tổng hợp/ Đơn vị đăng ký)",$col,$cc,"NTTD"))."</nobr></td>";
				echo "<td class='csA4A4F90C' colspan='2' style='width:216px;height:23px;'><nobr>".searchForId("Thuộc loại (Đơn vị tổng hợp/ Đơn vị đăng ký)",$col,$cc,"LDTD")."</nobr></td>";
			echo "</tr>";
			echo "<tr style='vertical-align:top;'>";
				echo "<td style='width:0px;height:24px;'></td>";
				echo "<td class='cs5017E93B' style='width:45px;height:23px;line-height:15px;text-align:center;vertical-align:middle;'><nobr>6</nobr></td>";
				echo "<td class='csA4A4F90C' colspan='2' style='width:298px;height:23px;line-height:15px;text-align:left;vertical-align:middle;'><nobr>	&nbsp;Thuộc&nbsp;khối&nbsp;(Bộ,&nbsp;cơ&nbsp;quan&nbsp;trung&nbsp;ương/Tỉnh,&nbsp;huyện,&nbsp;x&#227;)</nobr></td>";
				echo "<td class='csA4A4F90C' colspan='2' style='width:165px;height:23px;'><nobr>".searchForId("Thuộc khối (Bộ, cơ quan trung ương/ Tỉnh, huyện, xã)",$col,$cc,"TTKK")."</nobr></td>";
				echo "<td class='csA4A4F90C' colspan='3' style='width:207px;height:23px;'><nobr>".searchForId("Thuộc khối (Bộ, cơ quan trung ương/ Tỉnh, huyện, xã)",$col,$cc,"TTTD")."</nobr></td>";
				echo "<td class='csA4A4F90C' style='width:106px;height:23px;text-align:center;vertical-align:middle;'><nobr>".ngaythang(searchForId("Thuộc khối (Bộ, cơ quan trung ương/ Tỉnh, huyện, xã)",$col,$cc,"NTTD"))."</nobr></td>";
				echo "<td class='csA4A4F90C' colspan='2' style='width:216px;height:23px;'><nobr>".searchForId("Thuộc khối (Bộ, cơ quan trung ương/ Tỉnh, huyện, xã)",$col,$cc,"LDTD")."</nobr></td>";
			echo "</tr>";
			echo "<tr style='vertical-align:top;'>";
				echo "<td style='width:0px;height:111px;'></td>";
				echo "<td class='cs5017E93B' style='width:45px;height:110px;line-height:15px;text-align:center;vertical-align:middle;'><nobr>7</nobr></td>";
				echo "<td class='csA4A4F90C' colspan='2' style='width:298px;height:110px;line-height:15px;text-align:left;vertical-align:middle;'><nobr>Loại&nbsp;h&#236;nh&nbsp;đơn&nbsp;vị</nobr><br/><nobr>+&nbsp;Cơ&nbsp;quan&nbsp;nh&#224;&nbsp;nước&nbsp;(cơ&nbsp;quan&nbsp;h&#224;nh&nbsp;ch&#237;nh/cơ&nbsp;quan&nbsp;kh&#225;c)</nobr><br/><nobr>+&nbsp;Đơn&nbsp;vị&nbsp;sự&nbsp;nghiệp&nbsp;(gi&#225;o&nbsp;dục/&nbsp;y&nbsp;tế/&nbsp;văn&nbsp;h&#243;a/&nbsp;thể&nbsp;thao/</nobr><br/><nobr>khoa&nbsp;học&nbsp;c&#244;ng&nbsp;nghệ/&nbsp;sự&nbsp;nghiệp&nbsp;kh&#225;c;&nbsp;tự&nbsp;chủ&nbsp;t&#224;i</nobr><br/><nobr>ch&#237;nh/chưa&nbsp;tự&nbsp;chủ&nbsp;t&#224;i&nbsp;ch&#237;nh)</nobr><br/><nobr>+&nbsp;Tổ&nbsp;chức&nbsp;(ch&#237;nh&nbsp;trị/&nbsp;ch&#237;nh&nbsp;trị&nbsp;-&nbsp;x&#227;&nbsp;hội/&nbsp;ch&#237;nh&nbsp;trị&nbsp;x&#227;&nbsp;hội</nobr><br/><nobr>-&nbsp;nghề&nbsp;nghiệp/&nbsp;x&#227;&nbsp;hội/&nbsp;x&#227;&nbsp;hội&nbsp;-&nbsp;nghề&nbsp;nghiệp)</nobr></td>";
				echo "<td class='csA4A4F90C' colspan='2' style='width:165px;height:110px;'></td>";
				echo "<td class='csA4A4F90C' colspan='3' style='width:207px;height:110px;'></td>";
				echo "<td class='csA4A4F90C' style='width:106px;height:110px;'></td>";
				echo "<td class='csA4A4F90C' colspan='2' style='width:216px;height:110px;'></td>";
			echo "</tr>";
	}
	?>
	<!--đến đây-->
	
	<tr style="vertical-align:top;">
		<td style="width:0px;height:19px;"></td>
		<td class="cs62AA4CC9" colspan="6" style="width:517px;height:19px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
		<td class="cs62AA4CC9" colspan="4" style="width:517px;height:19px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
		<td></td>
	</tr>
	<tr style="vertical-align:top;">
		<td style="width:0px;height:20px;"></td>
		<td class="csB6E29E9B" colspan="6" style="width:517px;height:20px;line-height:18px;text-align:center;vertical-align:middle;"><nobr>NGƯỜI&nbsp;LẬP&nbsp;BIỂU</nobr></td>
		<td class="csB6E29E9B" colspan="4" style="width:517px;height:20px;line-height:18px;text-align:center;vertical-align:middle;"><nobr>THỦ&nbsp;TRƯỞNG&nbsp;CƠ&nbsp;QUAN,&nbsp;TỔ&nbsp;CHỨC,&nbsp;ĐƠN&nbsp;VỊ</nobr></td>
		<td></td>
	</tr>
	<tr style="vertical-align:top;">
		<td style="width:0px;height:20px;"></td>
		<td class="cs77A39B34" colspan="6" style="width:517px;height:20px;line-height:18px;text-align:center;vertical-align:middle;"><nobr>(K&#253;,&nbsp;họ&nbsp;t&#234;n)</nobr></td>
		<td class="cs77A39B34" colspan="4" style="width:517px;height:20px;line-height:18px;text-align:center;vertical-align:middle;"><nobr>(K&#253;,&nbsp;họ&nbsp;t&#234;n,&nbsp;đ&#243;ng&nbsp;dấu)</nobr></td>
		<td></td>
	</tr>
	<tr style="vertical-align:top;">
		<td style="width:0px;height:68px;"></td>
		<td class="csB6E29E9B" colspan="6" style="width:517px;height:68px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
		<td class="csB6E29E9B" colspan="4" style="width:517px;height:68px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
		<td></td>
	</tr>
</table>
</body>
</html>