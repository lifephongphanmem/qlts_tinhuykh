﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
<head>
	<title>Document</title>
	<meta HTTP-EQUIV='Content-Type' CONTENT='text/html; charset=utf-8'>
	<style type="text/css">
		.csE71035DC {color:#000000;background-color:transparent;border-left:#000000 1px solid;border-top:#000000 1px solid;border-right:#000000 1px solid;border-bottom:#000000 1px solid;font-family:Times New Roman; font-size:13px; font-weight:normal; font-style:normal; }
		.cs5017E93B {color:#000000;background-color:transparent;border-left:#000000 1px solid;border-top-style: none;border-right:#000000 1px solid;border-bottom:#000000 1px solid;font-family:Times New Roman; font-size:13px; font-weight:normal; font-style:normal; }
		.cs82D98BB6 {color:#000000;background-color:transparent;border-left-style: none;border-top:#000000 1px solid;border-right:#000000 1px solid;border-bottom:#000000 1px solid;font-family:Times New Roman; font-size:13px; font-weight:normal; font-style:normal; }
		.cs8FC8786E {color:#000000;background-color:transparent;border-left-style: none;border-top-style: none;border-right:#000000 1px solid;border-bottom:#000000 1px solid;font-family:Times New Roman; font-size:13px; font-weight:bold; font-style:normal; }
		.csA4A4F90C {color:#000000;background-color:transparent;border-left-style: none;border-top-style: none;border-right:#000000 1px solid;border-bottom:#000000 1px solid;font-family:Times New Roman; font-size:13px; font-weight:normal; font-style:normal; }
		.cs7384E3C7 {color:#000000;background-color:transparent;border-left-style: none;border-top-style: none;border-right-style: none;border-bottom:#000000 1px solid;font-family:Times New Roman; font-size:13px; font-weight:normal; font-style:normal; }
		.csB6E29E9B {color:#000000;background-color:transparent;border-left-style: none;border-top-style: none;border-right-style: none;border-bottom-style: none;font-family:Times New Roman; font-size:16px; font-weight:bold; font-style:normal; }
		.cs77A39B34 {color:#000000;background-color:transparent;border-left-style: none;border-top-style: none;border-right-style: none;border-bottom-style: none;font-family:Times New Roman; font-size:16px; font-weight:normal; font-style:italic; }
		.cs62AA4CC9 {color:#000000;background-color:transparent;border-left-style: none;border-top-style: none;border-right-style: none;border-bottom-style: none;font-family:Times New Roman; font-size:16px; font-weight:normal; font-style:normal; }
		.cs260D573 {color:#000000;background-color:transparent;border-left-style: none;border-top-style: none;border-right-style: none;border-bottom-style: none;font-family:Times New Roman; font-size:17px; font-weight:bold; font-style:normal; padding-left:2px;padding-right:2px;}
		.csF7D3565D {height:0px;width:0px;overflow:hidden;font-size:0px;line-height:0px;}
	</style>
</head>
<body leftMargin=10 topMargin=10 rightMargin=10 bottomMargin=10 style="background-color:#FFFFFF">
<table cellpadding="0" cellspacing="0" border="0" style="border-width:0px;empty-cells:show;width:1080px;height:925px;">
	<tr>
		<td style="width:0px;height:0px;"></td>
		<td style="height:0px;width:50px;"></td>
		<td style="height:0px;width:39px;"></td>
		<td style="height:0px;width:1px;"></td>
		<td style="height:0px;width:81px;"></td>
		<td style="height:0px;width:150px;"></td>
		<td style="height:0px;width:161px;"></td>
		<td style="height:0px;width:58px;"></td>
		<td style="height:0px;width:36px;"></td>
		<td style="height:0px;width:116px;"></td>
		<td style="height:0px;width:104px;"></td>
		<td style="height:0px;width:96px;"></td>
		<td style="height:0px;width:188px;"></td>
	</tr>
	<tr style="vertical-align:top;">
		<td style="width:0px;height:20px;"></td>
		<td class="csB6E29E9B" colspan="4" style="width:171px;height:20px;line-height:18px;text-align:left;vertical-align:middle;"><nobr>Bộ,&nbsp;tỉnh:</nobr></td>
		<td class="csB6E29E9B" colspan="2" style="width:311px;height:20px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
		<td></td>
		<td></td>
		<td></td>
		<td class="csB6E29E9B" colspan="3" style="width:388px;height:20px;line-height:18px;text-align:center;vertical-align:middle;"><nobr>Mẫu&nbsp;số&nbsp;04b-ĐK/TSNN</nobr></td>
	</tr>
	<tr style="vertical-align:top;">
		<td style="width:0px;height:20px;"></td>
		<td class="csB6E29E9B" colspan="4" style="width:171px;height:20px;line-height:18px;text-align:left;vertical-align:middle;"><nobr>Đơn&nbsp;vị&nbsp;chủ&nbsp;quản:</nobr></td>
		<td class="csB6E29E9B" colspan="2" style="width:311px;height:20px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
		<td></td>
		<td></td>
		<td></td>
		<td class="cs62AA4CC9" colspan="3" rowspan="2" style="width:388px;height:40px;line-height:18px;text-align:center;vertical-align:middle;"><nobr>(Ban&nbsp;h&#224;nh&nbsp;theo&nbsp;Th&#244;ng&nbsp;tư&nbsp;số&nbsp;09/2012/TT-BTC</nobr><br/><nobr>ng&#224;y&nbsp;19/01/2012&nbsp;của&nbsp;Bộ&nbsp;t&#224;i&nbsp;ch&#237;nh)</nobr></td>
	</tr>
	<tr style="vertical-align:top;">
		<td style="width:0px;height:20px;"></td>
		<td class="csB6E29E9B" colspan="4" style="width:171px;height:20px;line-height:18px;text-align:left;vertical-align:middle;"><nobr>Đơn&nbsp;vị&nbsp;sử&nbsp;dụng&nbsp;t&#224;i&nbsp;sản:</nobr></td>
		<td class="csB6E29E9B" colspan="2" style="width:311px;height:20px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
		<td></td>
		<td></td>
		<td></td>
	</tr>
	<tr style="vertical-align:top;">
		<td style="width:0px;height:21px;"></td>
		<td class="csB6E29E9B" colspan="4" style="width:171px;height:21px;line-height:18px;text-align:left;vertical-align:middle;"><nobr>M&#227;&nbsp;đơn&nbsp;vị:</nobr></td>
		<td class="csB6E29E9B" colspan="2" style="width:311px;height:21px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
	</tr>
	<tr style="vertical-align:top;">
		<td style="width:0px;height:20px;"></td>
		<td class="csB6E29E9B" colspan="4" style="width:171px;height:20px;line-height:18px;text-align:left;vertical-align:middle;"><nobr>Loại&nbsp;h&#236;nh&nbsp;đơn&nbsp;vị:</nobr></td>
		<td class="csB6E29E9B" colspan="2" style="width:311px;height:20px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
	</tr>
	<tr style="vertical-align:top;">
		<td style="width:0px;height:17px;"></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
	</tr>
	<tr style="vertical-align:top;">
		<td style="width:0px;height:45px;"></td>
		<td class="cs260D573" colspan="12" style="width:1076px;height:45px;line-height:20px;text-align:center;vertical-align:middle;"><nobr>B&#193;O&nbsp;C&#193;O&nbsp;K&#202;&nbsp;KHAI</nobr><br/><nobr>THAY&nbsp;ĐỔI&nbsp;TH&#212;NG&nbsp;TIN&nbsp;VỀ&nbsp;T&#192;I&nbsp;SẢN&nbsp;L&#192;&nbsp;TRỤ&nbsp;SỞ&nbsp;L&#192;M&nbsp;VIỆC,&nbsp;CƠ&nbsp;SỞ&nbsp;HOẠT&nbsp;ĐỘNG&nbsp;SỰ&nbsp;NGHIỆP</nobr></td>
	</tr>
	<tr style="vertical-align:top;">
		<td style="width:0px;height:20px;"></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
	</tr>
	<tr style="vertical-align:top;">
		<td style="width:0px;height:39px;"></td>
		<td class="csE71035DC" style="width:48px;height:37px;line-height:15px;text-align:center;vertical-align:middle;"><nobr>STT</nobr></td>
		<td class="cs82D98BB6" colspan="4" style="width:270px;height:37px;line-height:15px;text-align:center;vertical-align:middle;"><nobr>CHỈ&nbsp;TI&#202;U</nobr></td>
		<td class="cs82D98BB6" colspan="3" style="width:254px;height:37px;line-height:15px;text-align:center;vertical-align:middle;"><nobr>TH&#212;NG&nbsp;TIN&nbsp;Đ&#195;&nbsp;K&#202;&nbsp;KHAI</nobr></td>
		<td class="cs82D98BB6" colspan="2" style="width:219px;height:37px;line-height:15px;text-align:center;vertical-align:middle;"><nobr>TH&#212;NG&nbsp;TIN&nbsp;ĐỀ&nbsp;NGHỊ&nbsp;THAY&nbsp;ĐỔI</nobr></td>
		<td class="cs82D98BB6" style="width:95px;height:37px;line-height:15px;text-align:center;vertical-align:middle;"><nobr>NG&#192;Y&nbsp;TH&#193;NG</nobr><br/><nobr>THAY&nbsp;ĐỔI</nobr></td>
		<td class="cs82D98BB6" style="width:187px;height:37px;line-height:15px;text-align:center;vertical-align:middle;"><nobr>L&#221;&nbsp;DO&nbsp;THAY&nbsp;ĐỔI</nobr></td>
	</tr>
	<tr style="vertical-align:top;">
		<td style="width:0px;height:19px;"></td>
		<td class="cs5017E93B" style="width:48px;height:18px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
		<td class="cs8FC8786E" colspan="4" style="width:270px;height:18px;line-height:15px;text-align:left;vertical-align:middle;"><nobr>I.&nbsp;Về&nbsp;đất</nobr></td>
		<td class="csA4A4F90C" colspan="3" style="width:254px;height:18px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
		<td class="csA4A4F90C" colspan="2" style="width:219px;height:18px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
		<td class="csA4A4F90C" style="width:95px;height:18px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
		<td class="csA4A4F90C" style="width:187px;height:18px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
	</tr>
	<tr style="vertical-align:top;">
		<td style="width:0px;height:19px;"></td>
		<td class="cs5017E93B" style="width:48px;height:18px;line-height:15px;text-align:center;vertical-align:middle;"><nobr>1</nobr></td>
		<td class="csA4A4F90C" colspan="4" style="width:270px;height:18px;line-height:15px;text-align:left;vertical-align:middle;"><nobr>T&#234;n&nbsp;t&#224;i&nbsp;sản</nobr></td>
		<td class="csA4A4F90C" colspan="3" style="width:254px;height:18px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
		<td class="csA4A4F90C" colspan="2" style="width:219px;height:18px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
		<td class="csA4A4F90C" style="width:95px;height:18px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
		<td class="csA4A4F90C" style="width:187px;height:18px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
	</tr>
	<tr style="vertical-align:top;">
		<td style="width:0px;height:19px;"></td>
		<td class="cs5017E93B" style="width:48px;height:18px;line-height:15px;text-align:center;vertical-align:middle;"><nobr>2</nobr></td>
		<td class="csA4A4F90C" colspan="4" style="width:270px;height:18px;line-height:15px;text-align:left;vertical-align:middle;"><nobr>Địa&nbsp;chỉ&nbsp;khu&#244;n&nbsp;vi&#234;n&nbsp;đất</nobr></td>
		<td class="csA4A4F90C" colspan="3" style="width:254px;height:18px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
		<td class="csA4A4F90C" colspan="2" style="width:219px;height:18px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
		<td class="csA4A4F90C" style="width:95px;height:18px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
		<td class="csA4A4F90C" style="width:187px;height:18px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
	</tr>
	<tr style="vertical-align:top;">
		<td style="width:0px;height:20px;"></td>
		<td class="cs5017E93B" style="width:48px;height:19px;line-height:15px;text-align:center;vertical-align:middle;"><nobr>3</nobr></td>
		<td class="csA4A4F90C" colspan="4" style="width:270px;height:19px;line-height:15px;text-align:left;vertical-align:middle;"><nobr>Tổng&nbsp;diện&nbsp;t&#237;ch&nbsp;(m2)</nobr></td>
		<td class="csA4A4F90C" colspan="3" style="width:254px;height:19px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
		<td class="csA4A4F90C" colspan="2" style="width:219px;height:19px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
		<td class="csA4A4F90C" style="width:95px;height:19px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
		<td class="csA4A4F90C" style="width:187px;height:19px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
	</tr>
	<tr style="vertical-align:top;">
		<td style="width:0px;height:19px;"></td>
		<td class="cs5017E93B" style="width:48px;height:18px;line-height:15px;text-align:center;vertical-align:middle;"><nobr>4</nobr></td>
		<td class="csA4A4F90C" colspan="4" style="width:270px;height:18px;line-height:15px;text-align:left;vertical-align:middle;"><nobr>Gi&#225;&nbsp;trị&nbsp;(ng&#224;n&nbsp;đồng)</nobr></td>
		<td class="csA4A4F90C" colspan="3" style="width:254px;height:18px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
		<td class="csA4A4F90C" colspan="2" style="width:219px;height:18px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
		<td class="csA4A4F90C" style="width:95px;height:18px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
		<td class="csA4A4F90C" style="width:187px;height:18px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
	</tr>
	<tr style="vertical-align:top;">
		<td style="width:0px;height:19px;"></td>
		<td class="cs5017E93B" style="width:48px;height:18px;line-height:15px;text-align:center;vertical-align:middle;"><nobr>5</nobr></td>
		<td class="csA4A4F90C" colspan="4" style="width:270px;height:18px;line-height:15px;text-align:left;vertical-align:middle;"><nobr>Hiện&nbsp;trạng&nbsp;sử&nbsp;dụng&nbsp;(m2)</nobr></td>
		<td class="csA4A4F90C" colspan="3" style="width:254px;height:18px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
		<td class="csA4A4F90C" colspan="2" style="width:219px;height:18px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
		<td class="csA4A4F90C" style="width:95px;height:18px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
		<td class="csA4A4F90C" style="width:187px;height:18px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
	</tr>
	<tr style="vertical-align:top;">
		<td style="width:0px;height:19px;"></td>
		<td class="cs5017E93B" style="width:48px;height:18px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
		<td class="cs7384E3C7" colspan="2" style="width:40px;height:18px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
		<td class="csA4A4F90C" colspan="2" style="width:230px;height:18px;line-height:15px;text-align:left;vertical-align:middle;"><nobr>+&nbsp;L&#224;m&nbsp;trụ&nbsp;sở&nbsp;l&#224;m&nbsp;việc</nobr></td>
		<td class="csA4A4F90C" colspan="3" style="width:254px;height:18px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
		<td class="csA4A4F90C" colspan="2" style="width:219px;height:18px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
		<td class="csA4A4F90C" style="width:95px;height:18px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
		<td class="csA4A4F90C" style="width:187px;height:18px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
	</tr>
	<tr style="vertical-align:top;">
		<td style="width:0px;height:19px;"></td>
		<td class="cs5017E93B" style="width:48px;height:18px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
		<td class="cs7384E3C7" colspan="2" style="width:40px;height:18px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
		<td class="csA4A4F90C" colspan="2" style="width:230px;height:18px;line-height:15px;text-align:left;vertical-align:middle;"><nobr>+&nbsp;L&#224;m&nbsp;cơ&nbsp;sở&nbsp;hoạt&nbsp;động&nbsp;sự&nbsp;nghiệp</nobr></td>
		<td class="csA4A4F90C" colspan="3" style="width:254px;height:18px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
		<td class="csA4A4F90C" colspan="2" style="width:219px;height:18px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
		<td class="csA4A4F90C" style="width:95px;height:18px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
		<td class="csA4A4F90C" style="width:187px;height:18px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
	</tr>
	<tr style="vertical-align:top;">
		<td style="width:0px;height:20px;"></td>
		<td class="cs5017E93B" style="width:48px;height:19px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
		<td class="cs7384E3C7" colspan="2" style="width:40px;height:19px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
		<td class="csA4A4F90C" colspan="2" style="width:230px;height:19px;line-height:15px;text-align:left;vertical-align:middle;"><nobr>+&nbsp;Cho&nbsp;thu&#234;</nobr></td>
		<td class="csA4A4F90C" colspan="3" style="width:254px;height:19px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
		<td class="csA4A4F90C" colspan="2" style="width:219px;height:19px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
		<td class="csA4A4F90C" style="width:95px;height:19px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
		<td class="csA4A4F90C" style="width:187px;height:19px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
	</tr>
	<tr style="vertical-align:top;">
		<td style="width:0px;height:19px;"></td>
		<td class="cs5017E93B" style="width:48px;height:18px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
		<td class="cs7384E3C7" colspan="2" style="width:40px;height:18px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
		<td class="csA4A4F90C" colspan="2" style="width:230px;height:18px;line-height:15px;text-align:left;vertical-align:middle;"><nobr>+&nbsp;L&#224;m&nbsp;nh&#224;&nbsp;ở</nobr></td>
		<td class="csA4A4F90C" colspan="3" style="width:254px;height:18px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
		<td class="csA4A4F90C" colspan="2" style="width:219px;height:18px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
		<td class="csA4A4F90C" style="width:95px;height:18px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
		<td class="csA4A4F90C" style="width:187px;height:18px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
	</tr>
	<tr style="vertical-align:top;">
		<td style="width:0px;height:19px;"></td>
		<td class="cs5017E93B" style="width:48px;height:18px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
		<td class="cs7384E3C7" colspan="2" style="width:40px;height:18px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
		<td class="csA4A4F90C" colspan="2" style="width:230px;height:18px;line-height:15px;text-align:left;vertical-align:middle;"><nobr>+&nbsp;Bỏ&nbsp;trống</nobr></td>
		<td class="csA4A4F90C" colspan="3" style="width:254px;height:18px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
		<td class="csA4A4F90C" colspan="2" style="width:219px;height:18px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
		<td class="csA4A4F90C" style="width:95px;height:18px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
		<td class="csA4A4F90C" style="width:187px;height:18px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
	</tr>
	<tr style="vertical-align:top;">
		<td style="width:0px;height:19px;"></td>
		<td class="cs5017E93B" style="width:48px;height:18px;line-height:15px;text-align:center;vertical-align:middle;"><nobr>6</nobr></td>
		<td class="csA4A4F90C" colspan="4" style="width:270px;height:18px;line-height:15px;text-align:left;vertical-align:middle;"><nobr>Th&#244;ng&nbsp;tin&nbsp;kh&#225;c</nobr></td>
		<td class="csA4A4F90C" colspan="3" style="width:254px;height:18px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
		<td class="csA4A4F90C" colspan="2" style="width:219px;height:18px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
		<td class="csA4A4F90C" style="width:95px;height:18px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
		<td class="csA4A4F90C" style="width:187px;height:18px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
	</tr>
	<tr style="vertical-align:top;">
		<td style="width:0px;height:19px;"></td>
		<td class="cs5017E93B" style="width:48px;height:18px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
		<td class="cs8FC8786E" colspan="4" style="width:270px;height:18px;line-height:15px;text-align:left;vertical-align:middle;"><nobr>II.&nbsp;Về&nbsp;nh&#224;</nobr></td>
		<td class="csA4A4F90C" colspan="3" style="width:254px;height:18px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
		<td class="csA4A4F90C" colspan="2" style="width:219px;height:18px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
		<td class="csA4A4F90C" style="width:95px;height:18px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
		<td class="csA4A4F90C" style="width:187px;height:18px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
	</tr>
	<tr style="vertical-align:top;">
		<td style="width:0px;height:20px;"></td>
		<td class="cs5017E93B" style="width:48px;height:19px;line-height:15px;text-align:center;vertical-align:middle;"><nobr>1</nobr></td>
		<td class="csA4A4F90C" colspan="4" style="width:270px;height:19px;line-height:15px;text-align:left;vertical-align:middle;"><nobr>T&#234;n&nbsp;nh&#224;</nobr></td>
		<td class="csA4A4F90C" colspan="3" style="width:254px;height:19px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
		<td class="csA4A4F90C" colspan="2" style="width:219px;height:19px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
		<td class="csA4A4F90C" style="width:95px;height:19px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
		<td class="csA4A4F90C" style="width:187px;height:19px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
	</tr>
	<tr style="vertical-align:top;">
		<td style="width:0px;height:19px;"></td>
		<td class="cs5017E93B" style="width:48px;height:18px;line-height:15px;text-align:center;vertical-align:middle;"><nobr>2</nobr></td>
		<td class="csA4A4F90C" colspan="4" style="width:270px;height:18px;line-height:15px;text-align:left;vertical-align:middle;"><nobr>Thuộc&nbsp;khu&#244;n&nbsp;vi&#234;n&nbsp;đất</nobr></td>
		<td class="csA4A4F90C" colspan="3" style="width:254px;height:18px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
		<td class="csA4A4F90C" colspan="2" style="width:219px;height:18px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
		<td class="csA4A4F90C" style="width:95px;height:18px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
		<td class="csA4A4F90C" style="width:187px;height:18px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
	</tr>
	<tr style="vertical-align:top;">
		<td style="width:0px;height:19px;"></td>
		<td class="cs5017E93B" style="width:48px;height:18px;line-height:15px;text-align:center;vertical-align:middle;"><nobr>3</nobr></td>
		<td class="csA4A4F90C" colspan="4" style="width:270px;height:18px;line-height:15px;text-align:left;vertical-align:middle;"><nobr>Tổng&nbsp;diện&nbsp;t&#237;ch&nbsp;(m2)</nobr></td>
		<td class="csA4A4F90C" colspan="3" style="width:254px;height:18px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
		<td class="csA4A4F90C" colspan="2" style="width:219px;height:18px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
		<td class="csA4A4F90C" style="width:95px;height:18px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
		<td class="csA4A4F90C" style="width:187px;height:18px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
	</tr>
	<tr style="vertical-align:top;">
		<td style="width:0px;height:19px;"></td>
		<td class="cs5017E93B" style="width:48px;height:18px;line-height:15px;text-align:center;vertical-align:middle;"><nobr>4</nobr></td>
		<td class="csA4A4F90C" colspan="4" style="width:270px;height:18px;line-height:15px;text-align:left;vertical-align:middle;"><nobr>Số&nbsp;tầng</nobr></td>
		<td class="csA4A4F90C" colspan="3" style="width:254px;height:18px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
		<td class="csA4A4F90C" colspan="2" style="width:219px;height:18px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
		<td class="csA4A4F90C" style="width:95px;height:18px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
		<td class="csA4A4F90C" style="width:187px;height:18px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
	</tr>
	<tr style="vertical-align:top;">
		<td style="width:0px;height:19px;"></td>
		<td class="cs5017E93B" style="width:48px;height:18px;line-height:15px;text-align:center;vertical-align:middle;"><nobr>5</nobr></td>
		<td class="csA4A4F90C" colspan="4" style="width:270px;height:18px;line-height:15px;text-align:left;vertical-align:middle;"><nobr>Nguy&#234;n&nbsp;gi&#225;&nbsp;(ng&#224;n&nbsp;đồng)</nobr></td>
		<td class="csA4A4F90C" colspan="3" style="width:254px;height:18px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
		<td class="csA4A4F90C" colspan="2" style="width:219px;height:18px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
		<td class="csA4A4F90C" style="width:95px;height:18px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
		<td class="csA4A4F90C" style="width:187px;height:18px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
	</tr>
	<tr style="vertical-align:top;">
		<td style="width:0px;height:20px;"></td>
		<td class="cs5017E93B" style="width:48px;height:19px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
		<td class="cs7384E3C7" style="width:39px;height:19px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
		<td class="csA4A4F90C" colspan="3" style="width:231px;height:19px;line-height:15px;text-align:left;vertical-align:middle;"><nobr>+&nbsp;Nguồn&nbsp;ng&#226;n&nbsp;s&#225;ch</nobr></td>
		<td class="csA4A4F90C" colspan="3" style="width:254px;height:19px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
		<td class="csA4A4F90C" colspan="2" style="width:219px;height:19px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
		<td class="csA4A4F90C" style="width:95px;height:19px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
		<td class="csA4A4F90C" style="width:187px;height:19px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
	</tr>
	<tr style="vertical-align:top;">
		<td style="width:0px;height:19px;"></td>
		<td class="cs5017E93B" style="width:48px;height:18px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
		<td class="cs7384E3C7" style="width:39px;height:18px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
		<td class="csA4A4F90C" colspan="3" style="width:231px;height:18px;line-height:15px;text-align:left;vertical-align:middle;"><nobr>+&nbsp;Nguồn&nbsp;kh&#225;c</nobr></td>
		<td class="csA4A4F90C" colspan="3" style="width:254px;height:18px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
		<td class="csA4A4F90C" colspan="2" style="width:219px;height:18px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
		<td class="csA4A4F90C" style="width:95px;height:18px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
		<td class="csA4A4F90C" style="width:187px;height:18px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
	</tr>
	<tr style="vertical-align:top;">
		<td style="width:0px;height:19px;"></td>
		<td class="cs5017E93B" style="width:48px;height:18px;line-height:15px;text-align:center;vertical-align:middle;"><nobr>6</nobr></td>
		<td class="csA4A4F90C" colspan="4" style="width:270px;height:18px;line-height:15px;text-align:left;vertical-align:middle;"><nobr>Gi&#225;&nbsp;trị&nbsp;c&#242;n&nbsp;lại&nbsp;(ng&#224;n&nbsp;đồng)</nobr></td>
		<td class="csA4A4F90C" colspan="3" style="width:254px;height:18px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
		<td class="csA4A4F90C" colspan="2" style="width:219px;height:18px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
		<td class="csA4A4F90C" style="width:95px;height:18px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
		<td class="csA4A4F90C" style="width:187px;height:18px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
	</tr>
	<tr style="vertical-align:top;">
		<td style="width:0px;height:19px;"></td>
		<td class="cs5017E93B" style="width:48px;height:18px;line-height:15px;text-align:center;vertical-align:middle;"><nobr>7</nobr></td>
		<td class="csA4A4F90C" colspan="4" style="width:270px;height:18px;line-height:15px;text-align:left;vertical-align:middle;"><nobr>Hiện&nbsp;trạng&nbsp;sử&nbsp;dụng&nbsp;(m2)</nobr></td>
		<td class="csA4A4F90C" colspan="3" style="width:254px;height:18px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
		<td class="csA4A4F90C" colspan="2" style="width:219px;height:18px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
		<td class="csA4A4F90C" style="width:95px;height:18px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
		<td class="csA4A4F90C" style="width:187px;height:18px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
	</tr>
	<tr style="vertical-align:top;">
		<td style="width:0px;height:19px;"></td>
		<td class="cs5017E93B" style="width:48px;height:18px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
		<td class="cs7384E3C7" style="width:39px;height:18px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
		<td class="csA4A4F90C" colspan="3" style="width:231px;height:18px;line-height:15px;text-align:left;vertical-align:middle;"><nobr>+&nbsp;L&#224;m&nbsp;trụ&nbsp;sở&nbsp;l&#224;m&nbsp;việc</nobr></td>
		<td class="csA4A4F90C" colspan="3" style="width:254px;height:18px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
		<td class="csA4A4F90C" colspan="2" style="width:219px;height:18px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
		<td class="csA4A4F90C" style="width:95px;height:18px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
		<td class="csA4A4F90C" style="width:187px;height:18px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
	</tr>
	<tr style="vertical-align:top;">
		<td style="width:0px;height:20px;"></td>
		<td class="cs5017E93B" style="width:48px;height:19px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
		<td class="cs7384E3C7" style="width:39px;height:19px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
		<td class="csA4A4F90C" colspan="3" style="width:231px;height:19px;line-height:15px;text-align:left;vertical-align:middle;"><nobr>+&nbsp;L&#224;m&nbsp;cơ&nbsp;sở&nbsp;hoạt&nbsp;động&nbsp;sự&nbsp;nghiệp</nobr></td>
		<td class="csA4A4F90C" colspan="3" style="width:254px;height:19px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
		<td class="csA4A4F90C" colspan="2" style="width:219px;height:19px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
		<td class="csA4A4F90C" style="width:95px;height:19px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
		<td class="csA4A4F90C" style="width:187px;height:19px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
	</tr>
	<tr style="vertical-align:top;">
		<td style="width:0px;height:19px;"></td>
		<td class="cs5017E93B" style="width:48px;height:18px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
		<td class="cs7384E3C7" style="width:39px;height:18px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
		<td class="csA4A4F90C" colspan="3" style="width:231px;height:18px;line-height:15px;text-align:left;vertical-align:middle;"><nobr>+&nbsp;Cho&nbsp;thu&#234;</nobr></td>
		<td class="csA4A4F90C" colspan="3" style="width:254px;height:18px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
		<td class="csA4A4F90C" colspan="2" style="width:219px;height:18px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
		<td class="csA4A4F90C" style="width:95px;height:18px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
		<td class="csA4A4F90C" style="width:187px;height:18px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
	</tr>
	<tr style="vertical-align:top;">
		<td style="width:0px;height:19px;"></td>
		<td class="cs5017E93B" style="width:48px;height:18px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
		<td class="cs7384E3C7" style="width:39px;height:18px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
		<td class="csA4A4F90C" colspan="3" style="width:231px;height:18px;line-height:15px;text-align:left;vertical-align:middle;"><nobr>+&nbsp;L&#224;m&nbsp;nh&#224;&nbsp;ở</nobr></td>
		<td class="csA4A4F90C" colspan="3" style="width:254px;height:18px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
		<td class="csA4A4F90C" colspan="2" style="width:219px;height:18px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
		<td class="csA4A4F90C" style="width:95px;height:18px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
		<td class="csA4A4F90C" style="width:187px;height:18px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
	</tr>
	<tr style="vertical-align:top;">
		<td style="width:0px;height:19px;"></td>
		<td class="cs5017E93B" style="width:48px;height:18px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
		<td class="cs7384E3C7" style="width:39px;height:18px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
		<td class="csA4A4F90C" colspan="3" style="width:231px;height:18px;line-height:15px;text-align:left;vertical-align:middle;"><nobr>+&nbsp;Bỏ&nbsp;trống</nobr></td>
		<td class="csA4A4F90C" colspan="3" style="width:254px;height:18px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
		<td class="csA4A4F90C" colspan="2" style="width:219px;height:18px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
		<td class="csA4A4F90C" style="width:95px;height:18px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
		<td class="csA4A4F90C" style="width:187px;height:18px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
	</tr>
	<tr style="vertical-align:top;">
		<td style="width:0px;height:19px;"></td>
		<td class="cs5017E93B" style="width:48px;height:18px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
		<td class="cs7384E3C7" style="width:39px;height:18px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
		<td class="csA4A4F90C" colspan="3" style="width:231px;height:18px;line-height:15px;text-align:left;vertical-align:middle;"><nobr>+&nbsp;Sử&nbsp;dụng&nbsp;kh&#225;c</nobr></td>
		<td class="csA4A4F90C" colspan="3" style="width:254px;height:18px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
		<td class="csA4A4F90C" colspan="2" style="width:219px;height:18px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
		<td class="csA4A4F90C" style="width:95px;height:18px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
		<td class="csA4A4F90C" style="width:187px;height:18px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
	</tr>
	<tr style="vertical-align:top;">
		<td style="width:0px;height:20px;"></td>
		<td class="cs5017E93B" style="width:48px;height:19px;line-height:15px;text-align:center;vertical-align:middle;"><nobr>8</nobr></td>
		<td class="csA4A4F90C" colspan="4" style="width:270px;height:19px;line-height:15px;text-align:left;vertical-align:middle;"><nobr>Thời&nbsp;gian&nbsp;sử&nbsp;dụng&nbsp;được&nbsp;đ&#225;nh&nbsp;gi&#225;&nbsp;lại&nbsp;(năm)</nobr></td>
		<td class="csA4A4F90C" colspan="3" style="width:254px;height:19px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
		<td class="csA4A4F90C" colspan="2" style="width:219px;height:19px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
		<td class="csA4A4F90C" style="width:95px;height:19px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
		<td class="csA4A4F90C" style="width:187px;height:19px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
	</tr>
	<tr style="vertical-align:top;">
		<td style="width:0px;height:19px;"></td>
		<td class="cs5017E93B" style="width:48px;height:18px;line-height:15px;text-align:center;vertical-align:middle;"><nobr>9</nobr></td>
		<td class="csA4A4F90C" colspan="4" style="width:270px;height:18px;line-height:15px;text-align:left;vertical-align:middle;"><nobr>Th&#244;ng&nbsp;tin&nbsp;kh&#225;c</nobr></td>
		<td class="csA4A4F90C" colspan="3" style="width:254px;height:18px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
		<td class="csA4A4F90C" colspan="2" style="width:219px;height:18px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
		<td class="csA4A4F90C" style="width:95px;height:18px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
		<td class="csA4A4F90C" style="width:187px;height:18px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
	</tr>
	<tr style="vertical-align:top;">
		<td style="width:0px;height:19px;"></td>
		<td class="cs62AA4CC9" colspan="7" style="width:540px;height:19px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
		<td class="cs62AA4CC9" colspan="5" style="width:540px;height:19px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
	</tr>
	<tr style="vertical-align:top;">
		<td style="width:0px;height:20px;"></td>
		<td class="csB6E29E9B" colspan="7" style="width:540px;height:20px;line-height:18px;text-align:center;vertical-align:middle;"><nobr>NGƯỜI&nbsp;LẬP&nbsp;BIỂU</nobr></td>
		<td class="csB6E29E9B" colspan="5" style="width:540px;height:20px;line-height:18px;text-align:center;vertical-align:middle;"><nobr>THỦ&nbsp;TRƯỞNG&nbsp;CƠ&nbsp;QUAN,&nbsp;TỔ&nbsp;CHỨC,&nbsp;ĐƠN&nbsp;VỊ</nobr></td>
	</tr>
	<tr style="vertical-align:top;">
		<td style="width:0px;height:20px;"></td>
		<td class="cs77A39B34" colspan="7" style="width:540px;height:20px;line-height:18px;text-align:center;vertical-align:middle;"><nobr>(K&#253;,&nbsp;họ&nbsp;t&#234;n)</nobr></td>
		<td class="cs77A39B34" colspan="5" style="width:540px;height:20px;line-height:18px;text-align:center;vertical-align:middle;"><nobr>(K&#253;,&nbsp;họ&nbsp;t&#234;n,&nbsp;đ&#243;ng&nbsp;dấu)</nobr></td>
	</tr>
	<tr style="vertical-align:top;">
		<td style="width:0px;height:68px;"></td>
		<td class="csB6E29E9B" colspan="7" style="width:540px;height:68px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
		<td class="csB6E29E9B" colspan="5" style="width:540px;height:68px;"><!--[if lte IE 7]><div class="csF7D3565D"></div><![endif]--></td>
	</tr>
</table>
</body>
</html>