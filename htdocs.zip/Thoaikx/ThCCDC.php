<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
<head>
	<title>Document</title>
	<meta HTTP-EQUIV='Content-Type' CONTENT='text/html; charset=utf-8'>
	<style type="text/css">
		.csAA5B9630 {color:#000000;background-color:transparent;border-left:#000000 1px solid;border-top:#000000 1px solid;border-right:#000000 1px solid;border-bottom:#000000 1px solid;font-family:Times New Roman; font-size:16px; font-weight:bold; font-style:normal; }
		.csDC952B64 {color:#000000;background-color:transparent;border-left:#000000 1px solid;border-top-style: none;border-right:#000000 1px solid;border-bottom:#000000 1px solid;font-family:Times New Roman; font-size:16px; font-weight:bold; font-style:normal; }
		.cs7DC1BDF5 {color:#000000;background-color:transparent;border-left:#000000 1px solid;border-top-style: none;border-right:#000000 1px solid;border-bottom:#000000 1px solid;font-family:Times New Roman; font-size:16px; font-weight:normal; font-style:normal; }
		.cs425CAA45 {color:#000000;background-color:transparent;border-left-style: none;border-top:#000000 1px solid;border-right:#000000 1px solid;border-bottom:#000000 1px solid;font-family:Times New Roman; font-size:16px; font-weight:bold; font-style:normal; }
		.cs16D304E1 {color:#000000;background-color:transparent;border-left-style: none;border-top-style: none;border-right:#000000 1px solid;border-bottom:#000000 1px solid;font-family:Times New Roman; font-size:16px; font-weight:bold; font-style:normal; }
		.cs8556A6FD {color:#000000;background-color:transparent;border-left-style: none;border-top-style: none;border-right:#000000 1px solid;border-bottom:#000000 1px solid;font-family:Times New Roman; font-size:16px; font-weight:normal; font-style:normal; }
		.csB6E29E9B {color:#000000;background-color:transparent;border-left-style: none;border-top-style: none;border-right-style: none;border-bottom-style: none;font-family:Times New Roman; font-size:16px; font-weight:bold; font-style:normal; }
		.csE9F2AA97 {color:#000000;background-color:transparent;border-left-style: none;border-top-style: none;border-right-style: none;border-bottom-style: none;font-family:Times New Roman; font-size:16px; font-weight:bold; font-style:normal; padding-left:2px;padding-right:2px;}
		.cs77A39B34 {color:#000000;background-color:transparent;border-left-style: none;border-top-style: none;border-right-style: none;border-bottom-style: none;font-family:Times New Roman; font-size:16px; font-weight:normal; font-style:italic; }
		.cs62AA4CC9 {color:#000000;background-color:transparent;border-left-style: none;border-top-style: none;border-right-style: none;border-bottom-style: none;font-family:Times New Roman; font-size:16px; font-weight:normal; font-style:normal; }
		.cs2C853136 {color:#000000;background-color:transparent;border-left-style: none;border-top-style: none;border-right-style: none;border-bottom-style: none;font-family:Times New Roman; font-size:19px; font-weight:bold; font-style:normal; padding-left:2px;padding-right:2px;}
		.csF7D3565D {height:0px;width:0px;overflow:hidden;font-size:0px;line-height:0px;}
	</style>
<link rel="stylesheet" href="buttonPro.css"/>
</head>
<div style="margin-left: 1100px;">
<input id="in" type="submit" class="buttonPro medium blue" onclick="this.style.display ='none'; window.print()" value="In báo cáo"  />
</div>
<body leftMargin=10 topMargin=10 rightMargin=10 bottomMargin=10 style="background-color:#FFFFFF">
<table cellpadding="0" cellspacing="0" border="0" style="border-width:0px;empty-cells:show;width:725px;height:410px;">
	<tr>
		<td style="width:0px;height:0px;"></td>
		<td style="height:0px;width:46px;"></td>
		<td style="height:0px;width:50px;"></td>
		<td style="height:0px;width:253px;"></td>
		<td style="height:0px;width:13px;"></td>
		<td style="height:0px;width:52px;"></td>
		<td style="height:0px;width:34px;"></td>
		<td style="height:0px;width:170px;"></td>
		<td style="height:0px;width:8px;"></td>
		<td style="height:0px;width:99px;"></td>
	</tr>
	<tr style="vertical-align:top;">
		<td style="width:0px;height:25px;"></td>
		<td class="csE9F2AA97" colspan="6" style="width:444px;height:25px;line-height:18px;text-align:left;vertical-align:middle;"><nobr>T&#234;n&nbsp;đơn&nbsp;vị</nobr></td>
		<td></td>
		<td></td>
		<td></td>
	</tr>
	<tr style="vertical-align:top;">
		<td style="width:0px;height:32px;"></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
	</tr>
	<tr style="vertical-align:top;">
		<td style="width:0px;height:32px;"></td>
		<td></td>
		<td></td>
		<td class="cs2C853136" colspan="6" style="width:526px;height:32px;line-height:22px;text-align:center;vertical-align:middle;"><nobr>BẢNG&nbsp;TỔNG&nbsp;HỢP&nbsp;C&#212;NG&nbsp;CỤ&nbsp;DỤNG&nbsp;CỤ</nobr></td>
		<td></td>
	</tr>
	<tr style="vertical-align:top;">
		<td style="width:0px;height:37px;"></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
	</tr>
	<tr style="vertical-align:top;">
		<td style="width:0px;height:65px;"></td>
		<td class="csAA5B9630" style="width:44px;height:63px;line-height:18px;text-align:center;vertical-align:middle;"><nobr>Số</nobr><br/><nobr>TT</nobr></td>
		<td class="cs425CAA45" colspan="2" style="width:302px;height:63px;line-height:18px;text-align:center;vertical-align:middle;"><nobr>T&#234;n&nbsp;c&#244;ng&nbsp;cụ&nbsp;dụng&nbsp;cụ</nobr></td>
		<td class="cs425CAA45" colspan="2" style="width:64px;height:63px;line-height:18px;text-align:center;vertical-align:middle;"><nobr>Năm&nbsp;sử</nobr><br/><nobr>dụng</nobr></td>
		<td class="cs425CAA45" colspan="2" style="width:203px;height:63px;line-height:18px;text-align:center;vertical-align:middle;"><nobr>Nơi&nbsp;sử&nbsp;dụng</nobr></td>
		<td class="cs425CAA45" colspan="2" style="width:106px;height:63px;line-height:18px;text-align:center;vertical-align:middle;"><nobr>Nguy&#234;n&nbsp;gi&#225;</nobr></td>
	</tr>
<?php
require ("$_SERVER[DOCUMENT_ROOT]/thoaikx/general.php");
require ("$_SERVER[DOCUMENT_ROOT]/Main/connect.php");
	$sqlts = "Select tenchitiet,Year(ngayxuat) AS YearSD, CAPH, sotien, noisudung From tblxuatdung";
	$queryts=mysqli_query($con,$sqlts);
	$i=0; $sotien = 0;$tstien = 0;
	while($rowts=mysqli_fetch_array($queryts)){
		$i=$i+1;
		$tents = $rowts['tenchitiet'];
		$namsd = $rowts['YearSD'];
		$noisudung = $rowts['noisudung'];
		$sotien = dinhdangso($rowts['sotien']);		
		$tstien = $tstien + $rowts['sotien'];
		echo"<tr style='vertical-align:top;'>";
			echo"<td style='width:0px;height:24px;'></td>";
			echo"<td class='cs7DC1BDF5' style='width:44px;height:23px;text-align:center;'>$i</td>";
			echo"<td class='cs8556A6FD' colspan='2' style='width:302px;height:23px;text-align:left;'>$tents</td>";
			echo"<td class='cs8556A6FD' colspan='2' style='width:64px;height:23px;text-align:center;'>$namsd </td>";
			echo"<td class='cs8556A6FD' colspan='2' style='width:203px;height:23px;text-align:left;'>$noisudung</td>";
			echo"<td class='cs8556A6FD' colspan='2' style='width:106px;height:23px;text-align:right;'>$sotien</td>";
		echo"</tr>";
	}
	$tstien = dinhdangso($tstien);
	echo"<tr style='vertical-align:top;'>";
		echo"<td style='width:0px;height:24px;'></td>";
		echo"<td class='csDC952B64' style='width:44px;height:23px;'></td>";
		echo"<td class='cs16D304E1' colspan='2' style='width:302px;height:23px;line-height:18px;text-align:center;vertical-align:middle;'><nobr>Tổng&nbsp;cộng:</nobr></td>";
		echo"<td class='cs16D304E1' colspan='2' style='width:64px;height:23px;'></td>";
		echo"<td class='cs16D304E1' colspan='2' style='width:203px;height:23px;'></td>";
		echo"<td class='cs16D304E1' colspan='2' style='width:106px;height:23px;text-align:right;'>$tstien</td>";
	echo"</tr>";
?>
	<tr style="vertical-align:top;">
		<td style="width:0px;height:19px;"></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
	</tr>
	<tr style="vertical-align:top;">
		<td style="width:0px;height:20px;"></td>
		<td class="cs62AA4CC9" colspan="4" style="width:362px;height:20px;"></td>
		<td class="cs77A39B34" colspan="5" style="width:363px;height:20px;line-height:18px;text-align:center;vertical-align:middle;"><nobr>Ng&#224;y&nbsp;th&#225;ng&nbsp;kết&nbsp;xuất</nobr></td>
	</tr>
	<tr style="vertical-align:top;">
		<td style="width:0px;height:20px;"></td>
		<td class="csB6E29E9B" colspan="4" style="width:362px;height:20px;line-height:18px;text-align:center;vertical-align:middle;"><nobr>Kế&nbsp;to&#225;n&nbsp;trưởng</nobr></td>
		<td class="csB6E29E9B" colspan="5" style="width:363px;height:20px;line-height:18px;text-align:center;vertical-align:middle;"><nobr>Thủ&nbsp;trưởng&nbsp;đơn&nbsp;vị</nobr></td>
	</tr>
	<tr style="vertical-align:top;">
		<td style="width:0px;height:20px;"></td>
		<td class="cs77A39B34" colspan="4" style="width:362px;height:20px;line-height:18px;text-align:center;vertical-align:middle;"><nobr>(K&#253;,&nbsp;họ&nbsp;t&#234;n)</nobr></td>
		<td class="cs77A39B34" colspan="5" style="width:363px;height:20px;line-height:18px;text-align:center;vertical-align:middle;"><nobr>(K&#253;,&nbsp;họ&nbsp;t&#234;n,&nbsp;đ&#243;ng&nbsp;dấu)</nobr></td>
	</tr>
	<tr style="vertical-align:top;">
		<td style="width:0px;height:92px;"></td>
		<td class="csB6E29E9B" colspan="4" style="width:362px;height:92px;"></td>
		<td class="csB6E29E9B" colspan="5" style="width:363px;height:92px;"></td>
	</tr>
</table>
</body>
</html>