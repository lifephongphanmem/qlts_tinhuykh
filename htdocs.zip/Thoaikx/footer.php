	

	<!-- Imported styles on this page -->
	<link rel="stylesheet" href="/QLTS/assets/js/datatables/responsive/css/datatables.responsive.css">
	<link rel="stylesheet" href="/QLTS/assets/js/select2/select2-bootstrap.css">
	<link rel="stylesheet" href="/QLTS/assets/js/select2/select2.css">

	<!-- Bottom scripts (common) -->
	<script src="/QLTS/assets/js/gsap/main-gsap.js"></script>
	<script src="/QLTS/assets/js/jquery-ui/js/jquery-ui-1.10.3.minimal.min.js"></script>
	<script src="/QLTS/assets/js/bootstrap.js"></script>
	<script src="/QLTS/assets/js/joinable.js"></script>
	<script src="/QLTS/assets/js/resizeable.js"></script>
	<script src="/QLTS/assets/js/neon-api.js"></script>
	<script src="/QLTS/assets/js/jquery.dataTables.min.js"></script>
	<script src="/QLTS/assets/js/datatables/TableTools.min.js"></script>


	<!-- Imported scripts on this page -->
	<script src="/QLTS/assets/js/dataTables.bootstrap.js"></script>
	<script src="/QLTS/assets/js/datatables/jquery.dataTables.columnFilter.js"></script>
	<script src="/QLTS/assets/js/datatables/lodash.min.js"></script>
	<script src="/QLTS/assets/js/datatables/responsive/js/datatables.responsive.js"></script>
	<script src="/QLTS/assets/js/select2/select2.min.js"></script>
	<script src="/QLTS/assets/js/neon-chat.js"></script>


	<!-- JavaScripts initializations and stuff -->
	<script src="/QLTS/assets/js/neon-custom.js"></script>


	<!-- Demo Settings -->
	<script src="/QLTS/assets/js/neon-demo.js"></script>

</body>
</html>