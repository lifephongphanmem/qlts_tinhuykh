<head>
<meta charset='utf-8'>
<?php
require ("$_SERVER[DOCUMENT_ROOT]/Main/connect.php");
require ("$_SERVER[DOCUMENT_ROOT]/Main/general.php");
require ("$_SERVER[DOCUMENT_ROOT]/Main/toolexcel.php");
	$phanloai = "";
	$tungay = "";
	$denngay = "";
	$madv ="";
	if(isset($_POST['create'])){
	if ($_POST['sobg'] != "")
		$phanloai = explode('>',$_POST['sobg']);	
	$tungay = $_POST['nttu'];
	$denngay = $_POST['ntden'];
	$madv = explode('>',$_POST['MADV']);
	$msdv = $madv[0];			
	if($_POST['donvi'] != "")
		$msdv = $_POST['donvi'];
	}
if(isset($_POST['noidung']))
	$noidung = $_POST['noidung'];
$machuong ="";
$sql = "Select machuong from thongtindonvi where madonvi = '$madv[0]'";
$qrsql = mysqli_query($con,$sql);
while($row = mysqli_fetch_array($qrsql)) {
	$machuong = $row['machuong'];
}
?>
</head>
<body>

<?php

$cs=0;
//luu cac thong tin vao file excel
require_once 'Classes/PHPExcel.php';
require_once 'Classes/PHPExcel/IOFactory.php';
$objPHPExcel = new PHPExcel();
dulieumotcot($objPHPExcel,'A1','Mã chương: ','B','Time New Roman',11,'T','','',0,'');
dulieumotcot($objPHPExcel,'A2','Đơn vị báo cáo: '.$madv[2],'B','Time New Roman',11,'T','','',0,'');
dulieumotcot($objPHPExcel,'A3','Mã ĐV có QH với NS:','B','Time New Roman',11,'T','','',0,'');
dulieumotcot($objPHPExcel,'G1','Mẫu số B04 - H','B','Time New Roman',11,'','','K1',0,'');
dulieumotcot($objPHPExcel,'G2','(Ban hành theo QĐ số: 19/2006/QĐ-BTC','','Time New Roman',11,'','','K2',0,'');
dulieumotcot($objPHPExcel,'G3','ngày 30/03/2006 của Bộ trưởng BTC và sửa đổi,','','Time New Roman',11,'','','K3',0,'');
dulieumotcot($objPHPExcel,'G4','bổ sung theo thông tư số 185/2010/TT-BTC)','','Time New Roman',11,'','','K4',0,'');
dulieumotcot($objPHPExcel,'A5','BÁO CÁO TÌNH HÌNH TĂNG, GIẢM TSCĐ','B','Time New Roman',16,'','','K5',0,'');
dulieumotcot($objPHPExcel,'A6','Từ ngày: '.$tungay.' đến ngày '.$denngay,'','Time New Roman',11,'','','K6',0,'');
dulieumotcot($objPHPExcel,'A7','STT','B','Time New Roman',10,'','','A8',6,'C');
dulieumotcot($objPHPExcel,'B7','Loại tài sản cố định, nhóm tài sản cố định','B','Time New Roman',10,'','','B8',25,'C');
dulieumotcot($objPHPExcel,'C7','Đơn vị tính số lượng','B','Time New Roman',10,'','','C8',7,'C');
dulieumotcot($objPHPExcel,'D7','Số đầu năm','B','Time New Roman',10,'','','E7',7,'C');
dulieumotcot($objPHPExcel,'F7','Tăng trong năm','B','Time New Roman',10,'','','G7',7,'C');
dulieumotcot($objPHPExcel,'H7','Giảm trong năm','B','Time New Roman',10,'','','I7',7,'C');
dulieumotcot($objPHPExcel,'J7','Số cuối năm','B','Time New Roman',10,'','','K7',0,'C');
dulieumotcot($objPHPExcel,'D8','SL','B','Time New Roman',10,'','','',0,'C');
dulieumotcot($objPHPExcel,'E8','GT','B','Time New Roman',10,'','','',12,'C');
dulieumotcot($objPHPExcel,'F8','SL','B','Time New Roman',10,'','','',0,'C');
dulieumotcot($objPHPExcel,'G8','GT','B','Time New Roman',10,'','','',12,'C');
dulieumotcot($objPHPExcel,'H8','SL','B','Time New Roman',10,'','','',0,'C');
dulieumotcot($objPHPExcel,'I8','GT','B','Time New Roman',10,'','','',12,'C');
dulieumotcot($objPHPExcel,'J8','SL','B','Time New Roman',10,'','','',0,'C');
dulieumotcot($objPHPExcel,'K8','GT','B','Time New Roman',10,'','','',12,'C');
dulieumotcot($objPHPExcel,'A9','A','B','Time New Roman',10,'','','',0,'C');
dulieumotcot($objPHPExcel,'B9','B','B','Time New Roman',10,'','','',0,'C');
dulieumotcot($objPHPExcel,'C9','C','B','Time New Roman',10,'','','',0,'C');
dulieumotcot($objPHPExcel,'D9','1','B','Time New Roman',10,'','','',0,'C');
dulieumotcot($objPHPExcel,'E9','2','B','Time New Roman',10,'','','',0,'C');
dulieumotcot($objPHPExcel,'F9','3','B','Time New Roman',10,'','','',0,'C');
dulieumotcot($objPHPExcel,'G9','4','B','Time New Roman',10,'','','',0,'C');
dulieumotcot($objPHPExcel,'H9','5','B','Time New Roman',10,'','','',0,'C');
dulieumotcot($objPHPExcel,'I9','6','B','Time New Roman',10,'','','',0,'C');
dulieumotcot($objPHPExcel,'J9','7','B','Time New Roman',10,'','','',0,'C');
dulieumotcot($objPHPExcel,'K9','8','B','Time New Roman',10,'','','',0,'C');
kedong($objPHPExcel,'A7','K9',1,'Mỏng');
$tg =  array(array(0,"A","B","N","D",0,0,0,0,0,0,0,0));

//tính toán số giảm trong năm
function giamtk($msts,$condition)
{
	global $tungay;
	global $denngay;
	global $con;
	$soluong = 0;
	$sotien = 0;
	$kq = 0;
	$sql = "Select distinct tblqlts.DTKV,tblqlts.DTXD,ngansach+nguonkhac as NG ".
		" From tblqlts inner join tbldenghi on tblqlts.TTQLTS = tbldenghi.TTQLTS ".
		" Where tblqlts.TTQLTS = ". $msts ." and tbldenghi.ngaythang between '".doingay($tungay)."' and '".doingay($denngay)."'";
	$qrsql = mysqli_query($con,$sql);
	while($row = mysqli_fetch_array($qrsql))
	{
		$soluong = $row['DTKV'] + $row['DTXD'];
		$sotien = $row['NG'];
	}
	if($condition == "Số lượng")
		$kq = $soluong;
	if($condition == "Số tiền")
		$kq = $sotien;
	return $kq;
}
//tính số lượng
function tinhtoan($msts,$condition,$condition1,$tanggiam)
{
	global $con;
	global $tungay;
	global  $denngay;
	$soluongts = 0;
	$sotients = 0;
	$sotang = 0;
	$sogiam = 0;
	$sotientang = 0;
	$sotiengiam = 0;
	$kq = 0;
	//xác định số tiền tăng nguyên giá
	$sqltg = "Select lydotanggiam,soluong,ngansach,nguonkhac,tanggiam,year(ngaytanggiam) as nam,sotien".
		" from tbltanggiam where TTQLTS = " . $msts . " and ngaytanggiam <= '" . doingay($denngay) . "'";
		//	echo $sqltg;
	$querytg = mysqli_query($con, $sqltg);
	while ($rowtg = mysqli_fetch_array($querytg)) {
		if ($rowtg['tanggiam'] == "Tăng") {
			$sotang = $sotang + $rowtg['soluong'];
			$sotientang = $sotientang + $rowtg['ngansach'] + $rowtg['nguonkhac'];
		}
	}
	//Số lượng giảm trong kỳ
	$sql = "Select distinct tblqlts.DTKV,tblqlts.DTXD,ngansach+nguonkhac as NG ".
		" From tblqlts inner join tbldenghi on tblqlts.TTQLTS = tbldenghi.TTQLTS ".
		" Where tblqlts.TTQLTS = ". $msts ." and (tbldenghi.hinhthuc = 'Thanh lý'  or tbldenghi.hinhthuc = 'Điều chuyển')".
		($condition == "Đầu kỳ"? " and tbldenghi.ngaythang < '" . doingay($tungay) . "' ":"").
		($condition == "Trong kỳ"? " and tbldenghi.ngaythang between '" . doingay($tungay) . "' and '" . doingay($denngay) . "' ":"").
		($condition == "Cuối kỳ"? " and tbldenghi.ngaythang <= '" . doingay($denngay) . "' ":"");
	$qrsql = mysqli_query($con, $sql);
	while ($row = mysqli_fetch_array($qrsql)) {
		$sogiam = $row['DTKV'] + $row['DTXD'] + $sotang;
		$sotiengiam = $row['NG'] + $sotientang;
	}
	$sql = "Select distinct DTKV,DTXD,ngansach+nguonkhac as NG".
		" from tblqlts where TTQLTS = ". $msts.
		($condition == "Đầu kỳ"? " and (CASE WHEN year(tblqlts.ngaythangchuyen) > 0 THEN ngaythangchuyen < '" .  doingay($tungay) ."'  ELSE ngaysudung < '" . doingay($tungay) ."' END) ":"").
		($condition == "Trong kỳ"? " and (CASE WHEN year(tblqlts.ngaythangchuyen) > 0 THEN ngaythangchuyen between '" . doingay($tungay) . "' and '" . doingay($denngay) . "'  ELSE  ngaysudung between '" . doingay($tungay) . "' and '" . doingay($denngay) . "' END) ":"").
		($condition == "Cuối kỳ"? " and (CASE WHEN year(tblqlts.ngaythangchuyen) > 0 THEN ngaythangchuyen <= '" .  doingay($denngay) ."'  ELSE ngaysudung <= '" . doingay($denngay) ."' END)":"");
	//($condition == "Đầu kỳ"? " and ngaysudung < '" . doingay($tungay) . "' ":"").
	//($condition == "Trong kỳ"? " and ngaysudung between '" . doingay($tungay) . "' and '" . doingay($denngay) . "' ":"").
	//($condition == "Cuối kỳ"? " and ngaysudung <= '" . doingay($denngay) . "' ":"");
	$qrsql = mysqli_query($con, $sql);
	while ($row = mysqli_fetch_array($qrsql)) {
		$soluongts += $row['DTKV'] + $row['DTXD'];
		$sotients += $row['NG'];
	}
	if($condition1 == "Số lượng" && $tanggiam == "")
		$kq = $soluongts + $sotang - $sogiam;
	if($condition1 == "Số tiền" && $tanggiam == "")
		$kq = $sotients + $sotientang - $sotiengiam;
	if($tanggiam == "Tăng" && $condition1 == "Số lượng")
		$kq = $soluongts;
	if($tanggiam == "Giảm" && $condition1 == "Số lượng")
		$kq = $sogiam;
	if($tanggiam == "Tăng" && $condition1 == "Số tiền")
		$kq = $sotients;
	if($tanggiam == "Giảm" && $condition1 == "Số tiền")
		$kq =  $sotiengiam;
	return $kq;
}
$tg =  array(array(0,"A","B","N",0,0,0,0,0,0,0,0,"D"));
$cs=0;$i=0;
	//$_sQLdv="Select distinct thongtindonvi.madonvi, thongtindonvi.tendv from tbltanggiam inner join thongtindonvi on tbltanggiam.madonvi=thongtindonvi.madonvi where tbltanggiam.madonvi Like '$msdv%' and ngaytanggiam between '" . doingay($tungay) . "' and '" . doingay($denngay) . "'";
$_sQLdv="Select distinct thongtindonvi.madonvi, thongtindonvi.tendv from tblqlts inner join thongtindonvi on tblqlts.madonvi=thongtindonvi.madonvi where tblqlts.madonvi Like '$msdv%'";
	$_qdv=mysqli_query($con,$_sQLdv);
	$_aDV=array();
	while($_r=mysqli_fetch_array($_qdv)){
		$_aDV[]=array('ma'=>$_r['madonvi'],
						'ten'=>$_r['tendv']
				);
	}
	//Duyệt từng đơn vị
foreach($_aDV as $_madv) {
	$sqlts = "Select distinct tblqlts.TTQLTS,tblqlts.tenchitiet,tblqlts.DVT,tblqlts.DTKV,tblqlts.DTXD,tblqlts.chitiethinhthai,ngansach+nguonkhac as NG,tblqlts.ngaysudung
					from tblqlts inner join tbldanhsachqd32 on tblqlts.chitiethinhthai = tbldanhsachqd32.chitiethinhthai
					where noidung like '$noidung%' and tblqlts.madonvi = '$_madv[ma]'";
	if ($phanloai == "") {
		$sqlts = $sqlts . " and tblqlts.chitiethinhthai like '" . $phanloai . "%'";
	} else {
		$sqlts = $sqlts . " and (";
		$count = 0;
		$chars = str_split($_POST["sobg"]);
		foreach ($chars as &$char) {
			if ($char == '>') {
				$count++;
			}
		}
		for ($i = 0; $i < $count; $i++) {
			if ($i == $count - 1)
				$sqlts = $sqlts . "tblqlts.chitiethinhthai like '" . $phanloai[$i] . "%'";
			else
				$sqlts = $sqlts . "tblqlts.chitiethinhthai like '" . $phanloai[$i] . "%' or ";
		}
		$sqlts = $sqlts . ")";
	}
	$sqlts = $sqlts . " and (CASE WHEN year(tblqlts.ngaythangchuyen) > 0 THEN tblqlts.ngaythangchuyen <= '" .  doingay($denngay) ."'  ELSE tblqlts.ngaysudung <= '" . doingay($denngay) ."' END) ".
		" and tblqlts.TTQLTS not in (select TTQLTS from tbldenghi where (hinhthuc  = 'Thanh lý' or hinhthuc  = 'Điều chuyển') and ngaythang < '" . doingay($tungay) . "') order by tbldanhsachqd32.ttsx";
	$queryts=mysqli_query($con,$sqlts);

	$stdk=0;$sttkt=0;$sttkg=0;$stck=0;
	$tennhom="";$tents="";$dvt="";$tennhomsau="";
	$sl1=0;$sl2=0;$sl3=0;$sl4=0;$sl5=0;$sl6=0;$sl7=0;$sl8=0;
	while($rowts=mysqli_fetch_array($queryts)) {
		$nam1 = 0;
		$thang1 = 0;
		$nam2 = 0;
		$thang2 = 0;
		$chuoi1 = "";
		$chuoi2 = "";
		if ($rowts['ngaysudung'] != "") {
			$chuoi1 = explode('-', $rowts['ngaysudung']);
		}
		$ngaysd = doingay($rowts['ngaysudung']);
		$chuoi2 = explode('/', $tungay);
		$kq = 0;
		$tang = 0;
		$sttang = 0;
		$stgiam = 0;
		$kqtk = 0;
		$tangtk = 0;
		$sttangtk = 0;
		$stgiamtk = 0;
		//if ($rowts['DTKV'] + $rowts['DTXD'] + $tang > $kq) {
			$tg[$cs][0] = $cs + 1;
			$tg[$cs][1] = $rowts['tenchitiet'];
			$tg[$cs][2] = $rowts['DVT'];
			$tg[$cs][3] = $rowts['chitiethinhthai'];

			$tg[$cs][4] = tinhtoan($rowts['TTQLTS'],"Đầu kỳ","Số lượng","");
			$tg[$cs][5] = tinhtoan($rowts['TTQLTS'],"Đầu kỳ","Số tiền","");
			$tg[$cs][6] = tinhtoan($rowts['TTQLTS'],"Trong kỳ","Số lượng","Tăng");
			$tg[$cs][7] = tinhtoan($rowts['TTQLTS'],"Trong kỳ","Số tiền","Tăng");

			$tg[$cs][8] = tinhtoan($rowts['TTQLTS'],"Trong kỳ","Số lượng","Giảm");
			$tg[$cs][9] = tinhtoan($rowts['TTQLTS'],"Trong kỳ","Số tiền","Giảm");
			$tg[$cs][10] = tinhtoan($rowts['TTQLTS'],"Cuối kỳ","Số lượng","");
			$tg[$cs][11] = tinhtoan($rowts['TTQLTS'],"Cuối kỳ","Số tiền","");
			$tg[$cs][12] = $_madv['ten'];

			$cs = $cs + 1;
			//$stdk=$stdk + kieudouble($rowts['NG']) + $sttang - $stgiam;$sttkt=$sttkt+$sttangtk;$sttkg=$sttkg+$stgiamtk;$stck=$stck+kieudouble($rowts['NG']) + $sttang - $stgiam + $sttangtk - $stgiamtk;
		//}
	}
	///
	$nhomsl2=0;$nhomsl4=0;$nhomsl6=0;$nhomsl8=0;$j=0;$stt=0;
}
$index=10;
$tennhomsau = "";
$tennhom="";
$group1=0;
$tennhomsau1 = "";
$tennhom1="";
$sogr1=0;
$sogr2=0;
$tong6=0;
$tong8=0;
$tong10=0;
$tong12=0;
$sttn1=0;
$tongdv6=0;
$tongdv8 =0;
$tongdv10 =0;
$tongdv12 =0;
for($i = 0; $i < $cs; $i++) {
	$tennhom=$tg[$i][12];
	if ($tennhom != $tennhomsau) {
		$sogr1 = $sogr1 + 1;
		$objPHPExcel->setActiveSheetIndex(0)
			->setCellValue('B' . $index, $tg[$i][12])->mergeCells('B' . $index . ':K' . $index);
		dinhdangBI($objPHPExcel, 'A' . $index, 'K' . $index, 1, 'B');
		$index++;
		$tennhomsau = $tg[$i][12];
	}
	$tennhom1 = $tg[$i][3];
	if ($tennhom1 != $tennhomsau1) {
		$sogr2 = $sogr2 + 1;
		$objPHPExcel->setActiveSheetIndex(0)
			->setCellValue('B' . $index , $tg[$i][3]);
		dinhdangBI($objPHPExcel, 'A' . $index, 'K' . $index , 1, 'BI');
		$sttn1 = $sttn1 + 1;
		$group1 = $index;
		$index++;
		$tennhomsau1 = $tg[$i][3];
	}
	$objPHPExcel->setActiveSheetIndex(0)
		->setCellValue('A' . $index, $i + 1)
		->setCellValue('B' . $index, $tg[$i][1])
		->setCellValue('C' . $index, $tg[$i][2])
		->setCellValue('D' . $index, $tg[$i][4])
		->setCellValue('E' . $index, $tg[$i][5])
		->setCellValue('F' . $index, $tg[$i][6])
		->setCellValue('G' . $index, $tg[$i][7])
		->setCellValue('H' . $index, $tg[$i][8])
		->setCellValue('I' . $index, $tg[$i][9])
		->setCellValue('J' . $index, $tg[$i][10])
		->setCellValue('K' . $index, $tg[$i][11]);
	$tong6 +=  $tg[$i][5];
	$tong8 +=  $tg[$i][7];
	$tong10 +=  $tg[$i][9];
	$tong12 +=  $tg[$i][11];
	$objPHPExcel->setActiveSheetIndex(0)
		->setCellValue('E' . $group1, "=Sum(E" . ($group1+1) . ":E" . $index . ")")
		->setCellValue('G' . $group1, "=Sum(G" . ($group1+1) . ":G" . $index . ")")
		->setCellValue('I' . $group1, "=Sum(I" . ($group1+1) . ":I" . $index . ")")
		->setCellValue('K' . $group1, "=Sum(K" . ($group1+1) . ":K" . $index . ")");
	$index++;
}
dulieumotcot($objPHPExcel,'B'.$index,'Tổng cộng','B','Time New Roman',10,'','','',0,'');
dulieumotcot($objPHPExcel,'E'.$index,$tong6,'B','Time New Roman',10,'','','',0,'');
dulieumotcot($objPHPExcel,'G'.$index,$tong8,'B','Time New Roman',10,'','','',0,'');
dulieumotcot($objPHPExcel,'I'.$index,$tong10,'B','Time New Roman',10,'','','',0,'');
dulieumotcot($objPHPExcel,'K'.$index,$tong12,'B','Time New Roman',10,'','','',0,'');
// truyền dữ liệu
dinhdangfont($objPHPExcel,'A10','K'.$index,$i,'Time New Roman',10);
dinhdangle($objPHPExcel,'A10','A'.$index,$i,'');
dinhdangle($objPHPExcel,'B10','C'.$index,$i,'T');
dinhdangle($objPHPExcel,'D10','K'.$index,$i,'P');
dinhdangsoxls($objPHPExcel,'D10','D'.$index,$i,'1P');
dinhdangsoxls($objPHPExcel,'E10','E'.$index,$i,'BT');
dinhdangsoxls($objPHPExcel,'F10','F'.$index,$i,'1P');
dinhdangsoxls($objPHPExcel,'G10','G'.$index,$i,'BT');
dinhdangsoxls($objPHPExcel,'H10','H'.$index,$i,'1P');
dinhdangsoxls($objPHPExcel,'I10','I'.$index,$i,'BT');
dinhdangsoxls($objPHPExcel,'J10','J'.$index,$i,'1P');
dinhdangsoxls($objPHPExcel,'K10','K'.$index,$i,'BT');
dinhdangxuongdong($objPHPExcel,'B10','C'.$index,$i);
kedong($objPHPExcel,'A10','K'.$index,$i,'Mỏng');
$index++;
dulieumotcot($objPHPExcel,'H'.$index,'Hà Nội, ngày ... tháng ... năm ......','I','Time New Roman',11,'','','K'.$index,0,'');
$index++;
dulieumotcot($objPHPExcel,'B'.$index,'Người ghi sổ','B','Time New Roman',11,'','','',0,'');
dulieumotcot($objPHPExcel,'D'.$index,'Kế toán trưởng','B','Time New Roman',11,'','','',0,'');
dulieumotcot($objPHPExcel,'H'.$index,'Thủ trưởng đơn vị','B','Time New Roman',11,'','','K'.$index,0,'');
$index++;
dulieumotcot($objPHPExcel,'B'.$index,'(Ký, họ tên)','I','Time New Roman',11,'','','',0,'');
dulieumotcot($objPHPExcel,'D'.$index,'(Ký, họ tên)','I','Time New Roman',11,'','','',0,'');
dulieumotcot($objPHPExcel,'H'.$index,'(Ký, họ tên, đóng dấu)','I','Time New Roman',11,'','','K'.$index,0,'');
dulieumotcot($objPHPExcel,'B'.($index + 7),'Nguyễn Văn Sinh','B','Time New Roman',11,'','','',0,'');
dulieumotcot($objPHPExcel,'D'.($index + 7),'Nguyễn Văn Sinh','B','Time New Roman',11,'','','',0,'');
dulieumotcot($objPHPExcel,'H'.($index + 7),'Trần Thủ Trưởng','B','Time New Roman',11,'','','K'.($index + 7),0,'');
taofile($objPHPExcel,"BcTHTGTSCDdvxls.xls","$_SERVER[DOCUMENT_ROOT]\\data\\upload","");
?>
<div class="modal-header">
	<h4 class="modal-title" style="text-align:center;"><strong>Bạn đã tạo file excel thành công, hãy tải file về để xem</strong></h4>
</div>
<a href="download.php?id=\data\upload\BcTHTGTSCDdvxls.xls">Bấm vào đây để tải file về</a>
</body>